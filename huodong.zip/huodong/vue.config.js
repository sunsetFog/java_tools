// 王浩
// const baseUrl = 'http://10.39.35.99:8004'
// 姜文天
// const baseUrl = 'http://10.39.230.131:8004'
// 罗成
// const baseUrl = 'http://10.39.35.106:8004'
const baseUrl = 'https://blackbeard-test.4009515151.com'

module.exports = {
  publicPath: process.env.NODE_ENV === 'dev' ? '/' : '/',
  // publicPath: '/blackbeard',
  productionSourceMap: false,
  devServer: {
    host: 'localhost',
    port: 8080,
    proxy: {
      '/': {
        target: baseUrl,
        changeOrigin: true,
        autoOpenBrowser: true,
        assetsSubDirectory: 'static',
        ws: false,
        pathRewrite: {
          // '^/meiju-center': '/meiju-center'
        }
      }
    }
  },
  lintOnSave: process.env.NODE_ENV !== 'production'
}
