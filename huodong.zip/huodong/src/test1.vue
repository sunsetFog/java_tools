<template>
  <div>
  <div class="banner">
    <img class="title" :src="headerList.banner+'.png'" :srcset="headerList.banner+'_2x.png 2x,'+headerList.banner+'_3x.png 3x'"
      alt="">
    <div class="text">
      <button @click="toHerf">{{ headerList.homeWord }}</button>
      <a :href="headerList.serviceLink">
        <img :src="headerList.service+'.png'" :srcset="headerList.service+'_2x.png 2x,'+headerList.service+'_3x.png 3x'" alt="">
        <span>{{ headerList.serviceText }}</span>
      </a>
    </div>
  </div>
  
  <div :class="{'card': true, 'card-1': true, 'aoavip-card': $route.query.name == 'aoavip'}" v-for="(table, index) in headerList.table" :key="index">
    <div class="title" v-if="$route.query.name != 'aoavip'">
      <img class="gift" :src="table.gift+'.png'" :srcset="table.gift+'_2x.png 2x,'+table.gift+'_3x.png 3x'" alt="">
      <img class="giftText" :src="table.giftText+'.png'" :srcset="table.giftText+'_2x.png 2x,'+table.giftText+'_3x.png 3x'" alt="">
    </div>
    <div class="aoavip-title" v-else>

    </div>
    <div :class="{'table': true,'aoavip-table': $route.query.name == 'aoavip'}" v-for="(table_, index_) in table.table" :key="index_">
    <p v-if="!!table_.label">{{ table_.label }}</p>
      <table>
        <thead>
          <tr>
            <th v-for="(th, index1) in table_.th" :key="index1"><span v-html="th"></span></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(td, index2) in table_.td" :key="index2">
            <td v-for="(tds, index3) in td" :key="index3" :colspan="table_.th.length-td.length+1"><span v-html="tds"></span></td>
          </tr>
        </tbody>
      </table>
      <p v-if="!!table_.labelBottom"><span style="width: 100%;display: inline-block;" v-html=" table_.labelBottom"></span></p>
    </div>
  </div>
  <div class="footerWarning">
    <h3>
        <span class="left"></span>
        <div>活动说明</div>
        <span class="right"></span>
      </h3>
    <p><span v-html="headerList.warning"></span></p>
  </div>
</div>
</template>

<script>
import { templateList } from '@/api/home'
import message from '@/utils/message'
import kokshoucun from './assets/mock/kokshoucun.json'
import kokfucun from './assets/mock/kokfucun.json'
import kokliushui from './assets/mock/kokliushui.json'
import huatishoucun from './assets/mock/huatishoucun.json'
import huatifucun from './assets/mock/huatifucun.json'
import huatiliushui from './assets/mock/huatiliushui.json'
import leyushoucun from './assets/mock/leyushoucun.json'

import leyufucun from './assets/mock/leyufucun.json'
import leyuhaoli from './assets/mock/leyuhaoli.json'
import yameshoucun from './assets/mock/yameshoucun.json'
import yamefucun from './assets/mock/yamefucun.json'
import yameliushui from './assets/mock/yameliushui.json'
import oubaoshoucun from './assets/mock/oubaoshoucun.json'
import oubaofucun from './assets/mock/oubaofucun.json'

import oubaoliushui from './assets/mock/oubaoliushui.json'
import oubaoshiwu from './assets/mock/oubaoshiwu.json'
import aoashoucun from './assets/mock/aoashoucun.json'
import aoafucun from './assets/mock/aoafucun.json'
import aoaliushui from './assets/mock/aoaliushui.json'
import aoahaoli from './assets/mock/aoahaoli.json'
import aoavip from './assets/mock/aoavip.json'
import bobshoucun from './assets/mock/bobshoucun.json'

import bobfucun from './assets/mock/bobfucun.json'
import bobshiwu from './assets/mock/bobshiwu.json'
import beiboshoucun from './assets/mock/beiboshoucun.json'
import beibofucun from './assets/mock/beibofucun.json'
import beiboliushui from './assets/mock/beiboliushui.json'
import yaboshoucun from './assets/mock/yaboshoucun.json'
import niubaoshoucun from './assets/mock/niubaoshoucun.json'
import ledongshoucun from './assets/mock/ledongshoucun.json'
import ledongfucun from './assets/mock/ledongfucun.json'
export default {
  name: 'App',
  components: {
  },
  data(){
    return {
      headerList: {}
    }
  },
  created(){
    this.otherData()
    this.getJson()
  },
  methods:{
    otherData() {
    let search = this.$route.query
    let name = search.name
    switch (name) {
      case 'kokshoucun':
        this.headerList = kokshoucun
        break;
      case 'kokfucun':
        this.headerList = kokfucun
        break;
      case 'huatishoucun':
        this.headerList = huatishoucun
        break;
      case 'huatifucun':
        this.headerList = huatifucun
        break;
      case 'huatiliushui':
        this.headerList = huatiliushui
        break;
      case 'kokliushui':
        this.headerList = kokliushui
        break;
      case 'leyushoucun':
        this.headerList = leyushoucun
        break;
      case 'leyufucun':
        this.headerList = leyufucun
        break;
      case 'leyuhaoli':
        this.headerList = leyuhaoli
        break;
      case 'yameshoucun':
        this.headerList = yameshoucun
        break;
      case 'yamefucun':
        this.headerList = yamefucun
        break;
      case 'yameliushui':
        this.headerList = yameliushui
        break;
      case 'oubaoshoucun':
        this.headerList = oubaoshoucun
        break;
      case 'oubaofucun':
        this.headerList = oubaofucun
        break;
      case 'oubaoliushui':
        this.headerList = oubaoliushui
        break;
      case 'oubaoshiwu':
        this.headerList = oubaoshiwu
        break;
      case 'aoashoucun':
        this.headerList = aoashoucun
        break;
      case 'aoafucun':
        this.headerList = aoafucun
        break;
      case 'aoaliushui':
        this.headerList = aoaliushui
        break;
      case 'aoahaoli':
        this.headerList = aoahaoli
        break;
      case 'aoavip':
        this.headerList = aoavip
        break;
      case 'bobshoucun':
        this.headerList = bobshoucun
        break;
      case 'bobfucun':
        this.headerList = bobfucun
        break;
      case 'bobshiwu':
        this.headerList = bobshiwu
        break;
      case 'beiboshoucun':
        this.headerList = beiboshoucun
        break;
      case 'beibofucun':
        this.headerList = beibofucun
        break;
      case 'beiboliushui':
        this.headerList = beiboliushui
        break;
      case 'yaboshoucun':
        this.headerList = yaboshoucun
        break;
      case 'niubaoshoucun':
        this.headerList = niubaoshoucun
        break;
      case 'ledongshoucun':
        this.headerList = ledongshoucun
        break;
      case 'ledongfucun':
        this.headerList = ledongfucun
        break;
      // default:
        // this.headerList = kokshoucun
        // console.log(`Sorry, we are out of ${expr}.`);
    }
    },
    toHerf() {
      window.location.href=this.headerList.homeLink;
    },
    getJson() {
      let  data = { id: '42', userId: 0 }
      let arr = []
      let hrefs = window.location.href
      let search = hrefs.split('?')[1]
      if(!search){
        message.toastOnce('路径错误')
        return false
      }
      let one = search.split('&')[0]
      let oneList = one.split('=')
      console.log('---', oneList);
      if(search.split('&')[2]) {
        let one = search.split('&')[0]
        let oneList = one.split('=')
        let two = search.split('&')[1]
        let twoList = two.split('=')
        let three = search.split('&')[2]
        let threeList = three.split('=')
        arr = [...oneList, ...twoList, ...threeList]
      } else if(search.split('&')[1]) {
        let one = search.split('&')[0]
        let oneList = one.split('=')
        let two = search.split('&')[1]
        let twoList = two.split('=')
        arr = [...oneList, ...twoList]
      } else {
        let oneList = search.split('=')
        arr = oneList
      }
      if(!arr.includes('id')) {
        this.includess = false
        this.otherData()
      } else {
        this.includess = true
        arr.forEach((item, index) => {
          if(item == 'userId') {
            data.userId = arr[index+1]
          } else if(item == 'id'){
            data.id = arr [index+1]
          }
        })
        templateList(data).then(res => {
          console.log('res---', res);
        })
      }
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
