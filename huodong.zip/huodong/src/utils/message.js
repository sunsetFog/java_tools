import Vue from 'vue'

function _toastOnce () {
  let closed = true
  return function (text, duration = 1.5) {
    if (closed) {
      closed = false
      Vue.prototype.$message.error(text, duration, function () {
        closed = true
      })
    }
  }
}

export default {
  toastOnce: _toastOnce()
}