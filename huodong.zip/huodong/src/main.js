import Vue from 'vue'
import App from './App.vue'
import 'ant-design-vue/dist/antd.css';
import './style/common.css'
import './style/style.css'
import router from './router.js'
// import antDesign from 'ant-design-vue';

import { message } from 'ant-design-vue'


import Vant from 'vant';
import 'vant/lib/index.css';
Vue.use(Vant);

import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
Vue.use(ElementUI);

import Viewer from 'v-viewer'
import 'viewerjs/dist/viewer.css'
Vue.use(Viewer)
Viewer.setDefaults({
  Options: { 'inline': true, 'button': true, 'navbar': true, 'title': true, 'toolbar': true, 'tooltip': true, 'movable': true, 'zoomable': true, 'rotatable': true, 'scalable': true, 'transition': true, 'fullscreen': true, 'keyboard': true, 'url': 'data-source' }
})


import '@/view/luckDraw/rem.js'

// Vue.use(antDesign)

Vue.prototype.$message = message;

Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App),
}).$mount('#app')
