<template>
  <div class="two">
    <div v-if="includess">
      <img class="bg" :src="headerList.homeImg?headerList.homeImg:''" alt="">
    <div class="customer-service">
      <button @click="toHerf">{{ headerList.homeWord }}</button>
      <a :href="headerList.serviceLink">
        <img :src="headerList.service?(headerList.service+'.png'):''" alt="">
        <span>{{ headerList.serviceText }}</span>
      </a>
    </div>
    </div>
    <div v-else>
    <img class="bg" :src="headerList.homeImg+'.jpg'" alt="">
    <!-- <button>{{ headerList.homeWord }}</button> -->
    <!-- <a :href="headerList.serviceLink"></a> -->
    <div class="customer-service">
      <button @click="toHerf">{{ headerList.homeWord }}</button>
      <a :href="headerList.serviceLink">
        <img :src="headerList.service?(headerList.service+'.png'):''" alt="">
        <span>{{ headerList.serviceText }}</span>
        <!-- <span>{{}}</span> -->
      </a>
    </div>
    </div>
  </div>
</template>

<script>
import { templateList, gitConfig } from '@/api/home'
import aiyouxivip from './assets/mock2/aiyouxivip.json'
import aiyouxishoucun from './assets/mock2/aiyouxishoucun.json'
import aiyouxifucun from './assets/mock2/aiyouxifucun.json'
import aiyouxiliushui from './assets/mock2/aiyouxiliushui.json'
import yibeifuhuo from './assets/mock2/yibeifuhuo.json'
import yibeishoucun from './assets/mock2/yibeishoucun.json'
import yibeiliushui from './assets/mock2/yibeiliushui.json'
import baoboshoucun from './assets/mock2/baoboshoucun.json'
import boleshoucun from './assets/mock2/boleshoucun.json'
import boleshiwu from './assets/mock2/boleshiwu.json'
import tianboshoucun from './assets/mock2/tianboshoucun.json'
import tianbofucun from './assets/mock2/tianbofucun.json'
import tianboshiwu from './assets/mock2/tianboshiwu.json'
import huanqiufuhuo from './assets/mock2/huanqiufuhuo.json'
import huanqiuliushui from './assets/mock2/huanqiuliushui.json'
import huanqiushiwu from './assets/mock2/huanqiushiwu.json'
import huanqiushoucun from './assets/mock2/huanqiushoucun.json'
import huanqiuvip from './assets/mock2/huanqiuvip.json'
import huohushoucun from './assets/mock2/huohushoucun.json'
import huohuliushui from './assets/mock2/huohuliushui.json'
import huohufucun from './assets/mock2/huohufucun.json'
import huohuvip from './assets/mock2/huohuvip.json'

import aoashoucun from './assets/mock2/aoashoucun.json'
import aoaliushui from './assets/mock2/aoaliushui.json'
import aoahaoli from './assets/mock2/aoahaoli.json'
import aoafucun from './assets/mock2/aoafucun.json'

import beiboliushui from './assets/mock2/beiboliushui.json'
import beibofucun from './assets/mock2/beibofucun.json'
import beiboshoucun from './assets/mock2/beiboshoucun.json'
import beibovip from './assets/mock2/beibovip.json'

import bobfucun from './assets/mock2/bobfucun.json'
import bobshiwu from './assets/mock2/bobshiwu.json'
import bobshoucun from './assets/mock2/bobshoucun.json'

import huatifucun from './assets/mock2/huatifucun.json'
import huatiliushui from './assets/mock2/huatiliushui.json'
import huatishoucun from './assets/mock2/huatishoucun.json'
import huativip from './assets/mock2/huativip.json'

import kokfucun from './assets/mock2/kokfucun.json'
import kokshoucun from './assets/mock2/kokshoucun.json'
import kokliushui from './assets/mock2/kokliushui.json'
import kokvip from './assets/mock2/kokvip.json'

import ledongfucun from './assets/mock2/ledongfucun.json'
import ledongshoucun from './assets/mock2/ledongshoucun.json'

import leyufucun from './assets/mock2/leyufucun.json'
import leyuvip from './assets/mock2/leyuvip.json'
import leyushoucun from './assets/mock2/leyushoucun.json'

import oubaofucun from './assets/mock2/oubaofucun.json'
import oubaoliushui from './assets/mock2/oubaoliushui.json'
import oubaoshiwu from './assets/mock2/oubaoshiwu.json'
import oubaoshoucun from './assets/mock2/oubaoshoucun.json'

import yamefucun from './assets/mock2/yamefucun.json'
import yamehaoli from './assets/mock2/yamehaoli.json'
import yameliushui from './assets/mock2/yameliushui.json'
import yameshoucun from './assets/mock2/yameshoucun.json'
import yamevip from './assets/mock2/yamevip.json'
import yaboshoucun from './assets/mock2/yaboshoucun.json'
import yaboliushui from './assets/mock2/yaboliushui.json'
import yabofucun from './assets/mock2/yabofucun.json'
import niubaoshoucun from './assets/mock2/niubaoshoucun.json'
import niubaofucun from './assets/mock2/niubaofucun.json'
import niubaovip from './assets/mock2/niubaovip.json'

import zunlongshoucun from './assets/mock2/zunlongshoucun.json'
import zunlongvip from './assets/mock2/zunlongvip.json'

import kaifashoucun from './assets/mock2/kaifashoucun.json'
import kaifavip from './assets/mock2/kaifavip.json'

import jiuyoushoucun from './assets/mock2/jiuyoushoucun.json'
import jiuyouvip from './assets/mock2/jiuyouvip.json'

import jinboshoucun from './assets/mock2/jinboshoucun.json'
import jinbofucun from './assets/mock2/jinbofucun.json'

import shoucun188 from './assets/mock2/188shoucun.json'
import fucun188 from './assets/mock2/188fucun.json'
import liushui188 from './assets/mock2/188liushui.json'

export default {
  name: 'App',
  components: {
  },
  data(){
    return {
      headerList: {},
      count: 1,
      includess: false
    }
  },
  created(){
    let search = this.$route.query
    let id = search.id
    let userId = search.userId
    let  data = { id: id, userId: userId }
    // let arr = []
    // console.log(!id,typeof id, id=='undefined')
    if(!id) {
      this.includess = false
      this.otherData()
    } else {
      this.includess = true
      templateList(data).then(res => {
      let headerList = res.data.data.template
      this.$set(this.headerList, 'homeWord', '进入'+headerList.gwName +'官方网站')
      this.$set(this.headerList, 'homeLink', headerList.gwJumpForH5)
      this.$set(this.headerList, 'homeImg', headerList.tpZp)
      this.$set(this.headerList, 'service', "/img2/service")
      this.$set(this.headerList, 'serviceText', "联系客服")
      this.$set(this.headerList, 'serviceLink', headerList.kefuJump)
      this.gitConfigList()
      })
    }

  },
  mounted(){
    // let w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth; 
    // let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    // this.count = h/w/2
    // console.log(w, h, this.count)
  },
  methods:{
    gitConfigList() {
      let search = this.$route.query
      let params = {
        "communityId": search.communityId,
        "inviteCode": search.inviteCode
      }
      // console.log(search, search.communityId, search.communityId!=='null')
      if (!!search.communityId&&(search.communityId!=='null')) {
        gitConfig(params).then(res => {
          let headerList = res.data.data
          headerList.h5_url&&this.$set(this.headerList, 'homeLink', headerList.h5_url)
          // headerList.qq&&this.$set(this.headerList, 'serviceLink', "tencent://message/?uin=" + headerList.qq + "&Site=&Menu-=yes")
          var kefu101 = "tencent://message/?uin=" + headerList.qq + "&Site=&Menu-=yes";
          var kefu102 = "mqqwpa://im/chat?chat_type=wpa&uin=" + headerList.qq + "&version=1&src_type=web&web_src=oicqzone.com";
          if (headerList.qq) {
            let regqq = this.checkInstalled('qq')
            if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent) || /(Android)/i.test(navigator.userAgent)) {
              this.$set(this.headerList, 'serviceLink', regqq?kefu102:'https://im.qq.com/immobile/index.html')
            } else {
              this.$set(this.headerList, 'serviceLink', regqq?kefu101:'https://im.qq.com/immobile/index.html')
            }
          }
        })
      }
    },
    toHerf() { 
      window.location.href=this.headerList.homeLink;
    },
     checkInstalled(m) {  
      switch(m){
      case 'msn':  
      try {  
        new ActiveXObject("MSNMessenger.P4QuickLaunch");  
        return true;  
      }  
      catch (e) {  
        return false;  
      }  
      case 'qq':  
      try {  
        new ActiveXObject("TimwpDll.TimwpCheck");  
        return true;  
      }  
      catch (e) {  
        return false;  
      }
      case 'skype':  
      try{  
        new ActiveXObject("Skype.Detection");  
        return true;  
      }catch(e){  
        return false;  
      } 

      }  
      },
    otherData() {
    let name = this.$route.query.name
    // this.headerList = tianbohuodong
    // console.log('jinbofucun', name)

    switch (name) {
      case 'aiyouxivip':
        this.headerList = aiyouxivip
        break;
      case 'aiyouxishoucun':
        this.headerList = aiyouxishoucun
        break;
      case 'aiyouxifucun':
        this.headerList = aiyouxifucun
        break;
      case 'aiyouxiliushui':
        this.headerList = aiyouxiliushui
        break;
      case 'huanqiufuhuo':
        this.headerList = huanqiufuhuo
        break;
      case 'huanqiuliushui':
        this.headerList = huanqiuliushui
        break;
      case 'huanqiushiwu':
        this.headerList = huanqiushiwu
        break;
      case 'huanqiushoucun':
        this.headerList = huanqiushoucun
        break;
      case 'huanqiuvip':
        this.headerList = huanqiuvip
        break;
      case 'yibeishoucun':
        this.headerList = yibeishoucun
        break;
      case 'yibeiliushui':
        this.headerList = yibeiliushui
        break;
      case 'yibeifuhuo':
        this.headerList = yibeifuhuo
        break;
      case 'baoboshoucun':
        this.headerList = baoboshoucun
        break;
      case 'boleshoucun':
        this.headerList = boleshoucun
        break;
      case 'boleshiwu':
        this.headerList = boleshiwu
        break;
      case 'tianboshoucun':
        this.headerList = tianboshoucun
        break;
      case 'tianbofucun':
        this.headerList = tianbofucun
        break;
      case 'tianboshiwu':
        this.headerList = tianboshiwu
        break;
      case 'huohuvip':
        this.headerList = huohuvip
        break;
      case 'huohushoucun':
        this.headerList = huohushoucun
        break;
      case 'huohuliushui':
        this.headerList = huohuliushui
        break;
      case 'huohufucun':
        this.headerList = huohufucun
        break;
      
      case 'aoashoucun':
        this.headerList = aoashoucun
        break;
      case 'aoaliushui':
        this.headerList = aoaliushui
        break;
      case 'aoahaoli':
        this.headerList = aoahaoli
        break;
      case 'aoafucun':
        this.headerList = aoafucun
        break;
      case 'beiboliushui':
        this.headerList = beiboliushui
        break;
      case 'beibofucun':
        this.headerList = beibofucun
        break;
      case 'beiboshoucun':
        this.headerList = beiboshoucun
        break;
      case 'beibovip':
        this.headerList = beibovip
        break;
      case 'bobfucun':
        this.headerList = bobfucun
        break;
      case 'bobshiwu':
        this.headerList = bobshiwu
        break;
      case 'bobshoucun':
        this.headerList = bobshoucun
        break;
      case 'huatifucun':
        this.headerList = huatifucun
        break;
      case 'huatiliushui':
        this.headerList = huatiliushui
        break;
      case 'huatishoucun':
        this.headerList = huatishoucun
        break;
      case 'huativip':
        this.headerList = huativip
        break;
      case 'kokfucun':
        this.headerList = kokfucun
        break;
      case 'kokvip':
        this.headerList = kokvip
        break;
      case 'kokshoucun':
        this.headerList = kokshoucun
        break;
      case 'kokliushui':
        this.headerList = kokliushui
        break;
      case 'ledongfucun':
        this.headerList = ledongfucun
        break;
      case 'ledongshoucun':
        this.headerList = ledongshoucun
        break;
      case 'leyufucun':
        this.headerList = leyufucun
        break;
      case 'leyuvip':
        this.headerList = leyuvip
        break;
      case 'leyushoucun':
        this.headerList = leyushoucun
        break;
      
      case 'oubaofucun':
        this.headerList = oubaofucun
        break;
      case 'oubaoliushui':
        this.headerList = oubaoliushui
        break;
      case 'oubaoshiwu':
        this.headerList = oubaoshiwu
        break;
      case 'oubaoshoucun':
        this.headerList = oubaoshoucun
        break;
      case 'yamefucun':
        this.headerList = yamefucun
        break;
      case 'yamehaoli':
        this.headerList = yamehaoli
        break;
      case 'yameliushui':
        this.headerList = yameliushui
        break;
      case 'yameshoucun':
        this.headerList = yameshoucun
        break;
      case 'yamevip':
        this.headerList = yamevip
        break;
      case 'yaboshoucun':
        this.headerList = yaboshoucun
        break;
      case 'yaboliushui':
        this.headerList = yaboliushui
        break;
      case 'yabofucun':
        this.headerList = yabofucun
        break;
      case 'niubaoshoucun':
        this.headerList = niubaoshoucun
        break;
      case 'niubaovip':
        this.headerList = niubaovip
        break;
      case 'niubaofucun':
        this.headerList = niubaofucun
        break;
      case 'zunlongshoucun':
        this.headerList = zunlongshoucun
        break;
      case 'zunlongvip':
        this.headerList = zunlongvip
        break;
      case 'kaifashoucun':
        this.headerList = kaifashoucun
        break;
      case 'kaifavip':
        this.headerList = kaifavip
        break;
      case 'jiuyoushoucun':
        this.headerList = jiuyoushoucun
        break;
      case 'jiuyouvip':
        this.headerList = jiuyouvip
        break;
      case 'shoucun188':
        this.headerList = shoucun188
        break;
      case 'fucun188':
        this.headerList = fucun188
        break;
      case 'liushui188':
        this.headerList = liushui188
        break;
      case 'jinboshoucun':
        this.headerList = jinboshoucun
        break;
      case 'jinbofucun':
        this.headerList = jinbofucun
        break;
      // default:
      //   this.headerList = yibeilibao
      }
      this.gitConfigList()
    }
  }
}
</script>

<style scoped>
.two .bg{
  width: 100%;
}

.two .customer-service {
  width: 100%;
  height: 2.75rem;
  position: absolute;
  top: 16.5rem;
  left: 0;
  width: 100%;
  padding: 0 1.4rem;
  box-sizing: border-box;
}

.two .customer-service button {
  width: 18rem;
  height: 2.75rem;
  position: absolute;
  top: -1.3rem;
  left: 2.5rem;
  background: #F9FAFF;
  color: #0674E4;
  border-radius: 0.5rem;
  padding: 0 0.62rem;
  border: 0;
  outline: 0;
  font-size: 1.18rem;
}

.two .customer-service a {
  position: absolute;
  top: 2rem;
  left: 8.5rem;
  height: 2.75rem;
  line-height: 2.75rem;
  color: #fff;
  text-decoration:none;
  font-size: 1rem;
}

.two .customer-service a img {
  vertical-align: middle;
  width: 1.12rem;
  margin-right: 0.62rem;
}
</style>
