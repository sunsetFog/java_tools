<template>
  <div class="two">
    <div v-if="includess">
      <img :src="headerList.homeImg" alt="">
    <div class="text">
      <button @click="toHerf">{{ headerList.homeWord }}</button>
      <a :href="headerList.serviceLink">
        <img :src="headerList.service+'.png'" :srcset="headerList.service+'_2x.png 2x,'+headerList.service+'_3x.png 3x'" alt="">
        <span>{{ headerList.serviceText }}</span>
      </a>
    </div>
    </div>
    <div v-else>
    <img :src="headerList.homeImg+'.jpg'" alt="">
    <!-- <button>{{ headerList.homeWord }}</button> -->
    <!-- <a :href="headerList.serviceLink"></a> -->
    <div class="text">
      <button @click="toHerf">{{ headerList.homeWord }}</button>
      <a :href="headerList.serviceLink">
        <img :src="headerList.service+'.png'" :srcset="headerList.service+'_2x.png 2x,'+headerList.service+'_3x.png 3x'" alt="">
        <span>{{ headerList.serviceText }}</span>
        <!-- <span>{{}}</span> -->
      </a>
    </div>
    </div>
  </div>
</template>

<script>
import { templateList } from '@/api/home'
 import message from '@/utils/message'
import aiyouxivip from './assets/mock2/aiyouxivip.json'
import aiyouxishoucun from './assets/mock2/aiyouxishoucun.json'
import aiyouxifucun from './assets/mock2/aiyouxifucun.json'
import aiyouxiliushui from './assets/mock2/aiyouxiliushui.json'
import yibeifuhuo from './assets/mock2/yibeifuhuo.json'
import yibeishoucun from './assets/mock2/yibeishoucun.json'
import yibeiliushui from './assets/mock2/yibeiliushui.json'
import baoboshoucun from './assets/mock2/baoboshoucun.json'
import boleshoucun from './assets/mock2/boleshoucun.json'
import boleshiwu from './assets/mock2/boleshiwu.json'
import tianboshoucun from './assets/mock2/tianboshoucun.json'
import tianbofucun from './assets/mock2/tianbofucun.json'
import tianboshiwu from './assets/mock2/tianboshiwu.json'
import huanqiufuhuo from './assets/mock2/huanqiufuhuo.json'
import huanqiuliushui from './assets/mock2/huanqiuliushui.json'
import huanqiushiwu from './assets/mock2/huanqiushiwu.json'
import huanqiushoucun from './assets/mock2/huanqiushoucun.json'
import huanqiuvip from './assets/mock2/huanqiuvip.json'
import huohushoucun from './assets/mock2/huohushoucun.json'
import huohuliushui from './assets/mock2/huohuliushui.json'
import huohufucun from './assets/mock2/huohufucun.json'
import huohuvip from './assets/mock2/huohuvip.json'

import aoashoucun from './assets/mock2/aoashoucun.json'
import aoaliushui from './assets/mock2/aoaliushui.json'
import aoahaoli from './assets/mock2/aoahaoli.json'
import aoafucun from './assets/mock2/aoafucun.json'

import beiboliushui from './assets/mock2/beiboliushui.json'
import beibofucun from './assets/mock2/beibofucun.json'
import beiboshoucun from './assets/mock2/beiboshoucun.json'

import bobfucun from './assets/mock2/bobfucun.json'
import bobshiwu from './assets/mock2/bobshiwu.json'
import bobshoucun from './assets/mock2/bobshoucun.json'

import huatifucun from './assets/mock2/huatifucun.json'
import huatiliushui from './assets/mock2/huatiliushui.json'
import huatishoucun from './assets/mock2/huatishoucun.json'

import kokfucun from './assets/mock2/kokfucun.json'
import kokshoucun from './assets/mock2/kokshoucun.json'
import kokliushui from './assets/mock2/kokliushui.json'

import ledongfucun from './assets/mock2/ledongfucun.json'
import ledongshoucun from './assets/mock2/ledongshoucun.json'

import leyufucun from './assets/mock2/leyufucun.json'
import leyuvip from './assets/mock2/leyuvip.json'
import leyushoucun from './assets/mock2/leyushoucun.json'

import oubaofucun from './assets/mock2/oubaofucun.json'
import oubaoliushui from './assets/mock2/oubaoliushui.json'
import oubaoshiwu from './assets/mock2/oubaoshiwu.json'
import oubaoshoucun from './assets/mock2/oubaoshoucun.json'

import yamefucun from './assets/mock2/yamefucun.json'
import yamehaoli from './assets/mock2/yamehaoli.json'
import yameliushui from './assets/mock2/yameliushui.json'
import yameshoucun from './assets/mock2/yameshoucun.json'
import yaboshoucun from './assets/mock2/yaboshoucun.json'
import niubaoshoucun from './assets/mock2/niubaoshoucun.json'

export default {
  name: 'App',
  components: {
  },
  data(){
    return {
      headerList: {},
      count: 1,
      includess: false
    }
  },
  created(){
    let  data = { id: '66', userId: 0 }
    let arr = []
    let hrefs = window.location.href
    let search = hrefs.split('?')[1]
    if(!search){
      message.toastOnce('路径错误')
      return false
    }
    // let one = search.split('&')[0]
    // let oneList = one.split('=')
    if(search.split('&')[2]) {
      let one = search.split('&')[0]
      let oneList = one.split('=')
      let two = search.split('&')[1]
      let twoList = two.split('=')
      let three = search.split('&')[2]
      let threeList = three.split('=')
      arr = [...oneList, ...twoList, ...threeList]
    } else if(search.split('&')[1]) {
      let one = search.split('&')[0]
      let oneList = one.split('=')
      let two = search.split('&')[1]
      let twoList = two.split('=')
      arr = [...oneList, ...twoList]
    } else {
      let oneList = search.split('=')
      arr = oneList
    }
    if(!arr.includes('id')) {
      this.includess = false
      this.otherData()
    } else {
      this.includess = true
    arr.forEach((item, index) => {
      if(item == 'userId') {
        data.userId = arr[index+1]
      } else if(item == 'id'){
        data.id = arr [index+1]
      }
    })
    templateList(data).then(res => {
      let headerList = res.data.data.template
      this.$set(this.headerList, 'homeWord', '进入'+headerList.gwName +'官方网站')
      this.$set(this.headerList, 'homeLink', headerList.gwJumpForH5)
      this.$set(this.headerList, 'homeImg', headerList.tpZp)
      this.$set(this.headerList, 'service', "/img2/service")
      this.$set(this.headerList, 'serviceText', "联系客服")
      this.$set(this.headerList, 'serviceLink', headerList.kefuJump)
      })
    }

  },
  mounted(){
    // let w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth; 
    // let h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    // this.count = h/w/2
    // console.log(w, h, this.count)
  },
  methods:{
    toHerf() {
      window.location.href=this.headerList.homeLink;
    },
    otherData() {
      let search = window.location.href
    let name = search? search.split('=')[1]:''
    // this.headerList = tianbohuodong
    switch (name) {
      case 'aiyouxivip':
        this.headerList = aiyouxivip
        break;
      case 'aiyouxishoucun':
        this.headerList = aiyouxishoucun
        break;
      case 'aiyouxifucun':
        this.headerList = aiyouxifucun
        break;
      case 'aiyouxiliushui':
        this.headerList = aiyouxiliushui
        break;
      case 'huanqiufuhuo':
        this.headerList = huanqiufuhuo
        break;
      case 'huanqiuliushui':
        this.headerList = huanqiuliushui
        break;
      case 'huanqiushiwu':
        this.headerList = huanqiushiwu
        break;
      case 'huanqiushoucun':
        this.headerList = huanqiushoucun
        break;
      case 'huanqiuvip':
        this.headerList = huanqiuvip
        break;
      case 'yibeishoucun':
        this.headerList = yibeishoucun
        break;
      case 'yibeiliushui':
        this.headerList = yibeiliushui
        break;
      case 'yibeifuhuo':
        this.headerList = yibeifuhuo
        break;
      case 'baoboshoucun':
        this.headerList = baoboshoucun
        break;
      case 'boleshoucun':
        this.headerList = boleshoucun
        break;
      case 'boleshiwu':
        this.headerList = boleshiwu
        break;
      case 'tianboshoucun':
        this.headerList = tianboshoucun
        break;
      case 'tianbofucun':
        this.headerList = tianbofucun
        break;
      case 'tianboshiwu':
        this.headerList = tianboshiwu
        break;
      case 'huohuvip':
        this.headerList = huohuvip
        break;
      case 'huohushoucun':
        this.headerList = huohushoucun
        break;
      case 'huohuliushui':
        this.headerList = huohuliushui
        break;
      case 'huohufucun':
        this.headerList = huohufucun
        break;
      
      case 'aoashoucun':
        this.headerList = aoashoucun
        break;
      case 'aoaliushui':
        this.headerList = aoaliushui
        break;
      case 'aoahaoli':
        this.headerList = aoahaoli
        break;
      case 'aoafucun':
        this.headerList = aoafucun
        break;
      case 'beiboliushui':
        this.headerList = beiboliushui
        break;
      case 'beibofucun':
        this.headerList = beibofucun
        break;
      case 'beiboshoucun':
        this.headerList = beiboshoucun
        break;
      case 'bobfucun':
        this.headerList = bobfucun
        break;
      case 'bobshiwu':
        this.headerList = bobshiwu
        break;
      case 'bobshoucun':
        this.headerList = bobshoucun
        break;
      case 'huatifucun':
        this.headerList = huatifucun
        break;
      case 'huatiliushui':
        this.headerList = huatiliushui
        break;
      case 'huatishoucun':
        this.headerList = huatishoucun
        break;
      case 'kokfucun':
        this.headerList = kokfucun
        break;
      case 'kokshoucun':
        this.headerList = kokshoucun
        break;
      case 'kokliushui':
        this.headerList = kokliushui
        break;
      case 'ledongfucun':
        this.headerList = ledongfucun
        break;
      case 'ledongshoucun':
        this.headerList = ledongshoucun
        break;
      case 'leyufucun':
        this.headerList = leyufucun
        break;
      case 'leyuvip':
        this.headerList = leyuvip
        break;
      case 'leyushoucun':
        this.headerList = leyushoucun
        break;
      
      case 'oubaofucun':
        this.headerList = oubaofucun
        break;
      case 'oubaoliushui':
        this.headerList = oubaoliushui
        break;
      case 'oubaoshiwu':
        this.headerList = oubaoshiwu
        break;
      case 'oubaoshoucun':
        this.headerList = oubaoshoucun
        break;
      case 'yamefucun':
        this.headerList = yamefucun
        break;
      case 'yamehaoli':
        this.headerList = yamehaoli
        break;
      case 'yameliushui':
        this.headerList = yameliushui
        break;
      case 'yameshoucun':
        this.headerList = yameshoucun
        break;
      case 'yaboshoucun':
        this.headerList = yaboshoucun
        break;
      case 'niubaoshoucun':
        this.headerList = niubaoshoucun
        break;
      // default:
      //   this.headerList = yibeilibao
      }
    }
  }
}
</script>

<style>
.two img{
  width: 100%;
}

.two .text {
  /* color: #45586e;
  height: 21px;
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -ms-flex-align: center;
  align-items: center;
  -webkit-box-pack: center;
  -ms-flex-pack: center;
  justify-content: center;
  font-size: 12px; */
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
}

.two .text button {
  position: absolute;
  width: 290px;
  height: 44px;
  left: 50%;
  top: 270px;
  background: #F9FAFF;
  color: #0674E4;
  border-radius: 8px;
  border: 0;
  outline: 0;
  font-size: 19px;
  -webkit-transform: translateX(-50%);
  transform: translateX(-50%);
}

.two .text a {
  position: absolute;
  height: 22px;
  left: 50%;
  top: 340px;
  color: #fff;
  text-decoration:none;
  -webkit-transform: translateX(-50%);
  transform: translateX(-50%);
}

.two .text a img {
  vertical-align: middle;
  width: 18px;
  margin-right: 10px;
}

@media (max-width: 1150px) {
  .two .text button {
    top: 800px;
  }
  .two .text a {
    top: 1065px;
  }
}

@media (max-width: 768px) {
  .two .text button {
    /* width: 353px; */
    /* height: 70px; */
    top: 514px;
  }
  .two .text a {
    top: 640px;
  }
}

@media (max-width: 415px) {
  .two .text button {
    top: 270px;
  }
  .two .text a {
    top: 340px;
  }
}

@media (max-width: 412px) {
  .two .text button {
    top: 270px;
  }
  .two .text a {
    top: 340px;
  }
}

@media (max-width: 376px) {
  .two .text button {
    top: 245px;
  }
  .two .text a {
    top: 305px;
  }
}

@media (max-width: 360px) {
  .two .text button {
    top: 230px;
  }
  .two .text a {
    top: 290px;
  }
}

@media (max-width: 320px) {
  .two .text button {
    width: 260px;
    top: 205px;
  }
  .two .text a {
    top: 262px;
  }
}
</style>
