/**
 *
 * http配置
 *
 */

//  import baseUrl from '../utils/env-setup'
 import axios from 'axios'
//  import store from './../store'
 import message from '@/utils/message'
 
 // 超时时间
 axios.defaults.timeout = 1800000
 // 跨域请求，允许保存cookie
 axios.defaults.withCredentials = true
 // base请求url
 axios.defaults.baseURL = process.env.VUE_APP_BASE_API
 // axios.defaults.headers['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8' // 此处是增加的代码，设置请求头的类型
 axios.defaults.headers['Content-Type'] = 'application/json;charset=UTF-8' // 此处是增加的代码，设置请求头的类型
 axios.defaults.withCredentials = false
//  let access_ = getCookie('access_token')
//  let refreshToken = getCookie('refresh_token')
//  access_ = '69fe23fd-3dcf-4d85-94bf-49eb76dd88f4'
 // let refreshToken = 'bfdfaa9d-923c-4d0d-9498-7bd2f469bfe3'
 // let access_ = store.getters['user/getToken']
 // console.log(access_, 'access_00000000000000000')
 // console.log(45445454545)
 // let refreshToken = store.getters['user/getFreshToken']
//  let tokenData = {
//    accessToken: access_,
//    refreshToken: refreshToken
//  }
//  if (access_) {
//    axios.defaults.headers['x-client'] = 'web'
//    axios.defaults.headers['token'] = access_
//    axios.defaults.headers['Authorization'] = 'Bearer' + ' ' + access_
//    setCookie('access_token', access_)
//    setCookie('refresh_token', refreshToken)
//  }
//  store.dispatch('user/setToken', tokenData)
 // store.dispatch('user/setFreshToken', tokenData)
 
//  function setCookie (name, token) { // 设置过期时间，浏览器关闭，cookie自动删除
//    document.cookie = name + '=' + token + ';expires=' + '-1' + ';domain=.4009515151.com;path=/'
//  }
 
 // HTTPresponse拦截
 axios.interceptors.response.use(response => {
  //  if (!access_) {
  //    axios.defaults.headers['x-client'] = ''
  //    axios.defaults.headers['token'] = ''
  //    axios.defaults.headers['Authorization'] = 'Bearer' + ' '
  //  }
   // 系统级问题
  //  if (!response.data.data && response.data.msg != '请登录') { // 未登入
  //   message.toastOnce('数据未配置')
  //    // loginOut()
  //  }
  //  if (response.status === 500) { // 服务器500
  //    message.toastOnce('系统异常，请联系管理员')
  //  }
  //  if (response.status !== 200) {
  //    message.toastOnce('网络不稳定')
  //  }
   return response
 }, error => {
   if (error.toString().indexOf('500') > -1) {
     message.toastOnce('系统异常，请联系管理员')
   } else if (error.toString().indexOf('502') > -1) {
     message.toastOnce('系统异常，请联系管理员')
   } else if (error.toString().indexOf('503') > -1) {
     message.toastOnce('系统异常，请联系管理员')
   } else if (navigator.onLine === false) {
     message.toastOnce('连接失败，请确保网络可用')
   } else if (error.code == 'ECONNABORTED' && error.message.indexOf('timeout') != -1) {
     message.toastOnce('连接超时，请稍候重试')
   }
   return Promise.reject(new Error(error))
 })
 
 export default axios
 