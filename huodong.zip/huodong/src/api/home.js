import request from './request'

/**
 * 分页展示数据
 */
export function templateList (query) {
  return request({
    url: 'appApi/hotWelfareChild/template',
    method: 'get',
    params: query
  })
}

// 进入活动页记录
export function gitConfig (data) {
  return request({
    url: process.env.VUE_APP_BASE_API == 'http://bobovip2.com/' ? 'http://ag.bobovip2.com/agentApi/api/getAgentInfoSimple' : 'https://ag.bobovip8.com/agentApi/api/getAgentInfoSimple',
    method: 'post',
    data: data
  })
}


// 个人中秋活动抽奖信息
export function luckyDrawMyInfo (query) {
  return request({
    url: 'appApi/luckyDraw/myself',
    method: 'post',
    params: query
  })
}
// 开始进行抽奖
export function startLuckyDraw (query) {
  return request({
    url: 'appApi/luckyDraw/startLuckyDraw',
    method: 'post',
    params: query
  })
}

// App-活动抽奖玩家信息
export function gongGeMyInfo (query) {
  return request({
    url: 'appApi/ac1/luckyDraw/myself',
    method: 'post',
    params: query
  })
}
// APP-开始进行抽奖
export function startGongGe (query) {
  return request({
    url: 'appApi/ac1/luckyDraw/startLuckyDraw',
    method: 'post',
    params: query
  })
}
// APP-中奖记录
export function recordAppList (query, token) {
  return request({
    url: 'appApi/ac1/luckyDraw/record',
    method: 'post',
    params: query,
    headers: {
      'token': token
    }
  })
}
// PC-活动抽奖玩家信息
export function gongGeMyInfo2 (query) {
  return request({
    url: 'pcApi/ac1/luckyDraw/myself',
    method: 'post',
    params: query
  })
}
// PC-开始进行抽奖
export function startGongGe2 (query) {
  return request({
    url: 'pcApi/ac1/luckyDraw/startLuckyDraw',
    method: 'post',
    params: query
  })
}
// PC-中奖记录
export function recordPcList (query, token) {
  return request({
    url: 'pcApi/ac1/luckyDraw/record',
    method: 'post',
    params: query,
    headers: {
      'token': token
    }
  })
}

export function activityData (query) {
  return request({
    url: process.env.VUE_APP_activity_API + 'adminApi/web/activity/data/fetchData',
    method: 'get',
    params: query
  })
}

export function jupiter (query) {
  return request({
    url: 'appApi/app/activity/manager/get',
    method: 'get',
    params: query
  })
}
export function jupiterPc (query) {
  return request({
    url: 'pcApi/pc/activity/manager/get',
    method: 'get',
    params: query
  })
}

export function mercury (query) {
  return request({
    url: 'appApi/welfareV2/getCommunity',
    method: 'post',
    params: query
  })
}

export function welfareDetails (query) {
  return request({
    url: 'appApi/welfareV2/get',
    method: 'post',
    params: query
  })
}

export function pcWelfareDetails (query) {
  return request({
    url: 'pcApi/pc/welfareV2/get',
    method: 'post',
    params: query
  })
}
