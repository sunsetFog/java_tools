<template>
    <section id="turntable">
        <div class="every-day">
            <img class="servicio" @click="servier" src="/img5/servicio.gif"/>
        </div>
        
        <LuckyWheel
            class="lucky-wheel"
            ref="myLucky"
            width="532px"
            height="532px"
            :blocks="blocks"
            :prizes="prizes"
            :buttons="buttons"
            :defaultConfig="defaultConfig"
            :defaultStyle="defaultStyle"
            @start="startCallBack"
            @end="endCallBack"
        >
        </LuckyWheel>


        <div class="robot-box">
            <div class="speak" v-if="luckyNum != 0 && isLogin == 'yes'">
            今日还剩<span>&nbsp;{{luckyNum}}&nbsp;</span>次抽奖机会
            </div>
            <div class="speak" v-if="luckyNum == 0 && isLogin == 'yes'">
                波仔等你明天再来哟~
            </div>
            <div class="speak" v-if="isLogin == 'no'">
                你还未登录哟~
            </div>
            <img class="robot" src="/img5/robot.png" srcset="/img5/robot@2x.png 2x"/>
        </div>

        <div class="winning-record">
            <div class="mercury" @click="ruleOpen">活动规则</div>
            <div class="title-box">
                <img src="/img5/activityTitle.png" srcset="/img5/activityTitle@2x.png 2x"/>
            </div>
            <div class="winning-list" v-if="winning_list1.length != 0">
                <el-scrollbar style="width:100%;height:100%;">
                <ul>
                    <li v-for="(item,index) in winning_list1" :key="index">
                        <span>{{item.createTime}}</span>
                        <span>{{item.luckyName}}</span>
                    </li>
                </ul>
                <ul>
                    <li v-for="(item,index) in winning_list2" :key="index">
                        <span>{{item.createTime}}</span>
                        <span>{{item.luckyName}}</span>
                    </li>
                </ul>
                </el-scrollbar>
            </div>
            <p v-if="winning_list1.length != 0">本活动彩金及实物奖品有效期为7天 请在获得奖品后尽快领取</p>
            <img v-if="winning_list1.length == 0" class="pic-nohistory" src="/img4/pic_nohistory.png" srcset="/img4/pic_nohistory@2x.png 2x"/>
        </div>



        <van-dialog v-model="dialog_value"  width="344.96px">
          <div slot="default" class="prize-box">
            <img class="dialog-envelopes" src="/img4/bump_bg.png" srcset="/img4/bump_bg@2x.png 2x">
            <div class="thank-you" v-if="prize_type == 520">今日抽奖次数已用完，请明日再来哟~</div>
            <div class="thank-you" v-if="prize_type == 404">你还未登录，快去登录来抽奖吧~</div>
            <div class="thank-you" v-if="prize_type == 500">当前啵币余额不足，不可抽奖哦~</div>
            <div class="thank-you" v-if="prize_type == 501">网络繁忙，请稍后重试！</div>
            <!-- <div class="thank-you" v-if="prize_type == 0">每一次谢谢参与，都是中奖的序曲</div>
            <div class="thank-you" v-if="prize_type == 3 || prize_type == 6">现金奖励已自动发放到佣金钱包</div> -->
            <div class="thank-you" v-if="prize_type == 2 || prize_type == 5 || prize_type == 8 || prize_type == 11">截图此页面联系客服领取平台彩金</div>
            <div class="thank-you" v-if="prize_type == 0 || prize_type == 3 || prize_type == 6 || prize_type == 9">啵币奖励已自动发放到啵币账户</div>

            <el-button type="primary" class="dialog-cancel" @click="cancelPrize" size="small">确 定</el-button>
          </div>
        </van-dialog>


        <el-dialog title="活动规则" :visible.sync="rule_active" width="750px">
            <div class="rule-box">
              <ul class="activity-description">
                <li>1.中奖结果以界面弹窗为准，获得啵币奖品时，啵币直接转入个人啵币账户；</li>
                <li>2.抽中彩金或实物奖品时请与社区在线客服申请领取，彩金只可用于游戏平台娱乐使用，不可提现，彩金收益可提现；</li>
                <li>3.抽中实物礼品的用户，请准确填写的收货信息，感谢你对本活动的支持与理解；</li>
                <li>4.任何用户或团体都不能以不正常的方式进行的投注或套取活动优惠；</li>
                <li>5.为避免文字理解差异，波波社区保留本活动最终解释权。</li>
              </ul>
          </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" @click="rule_active = false" size="small">确 定</el-button>
            </div>
        </el-dialog>
    </section>
</template>

<script>
import { LuckyWheel } from '@lucky-canvas/vue';
import { gongGeMyInfo2, startGongGe2, recordPcList } from '@/api/home';
export default {
    name: "turntable",
    components: { LuckyWheel },
    data() {
        return {
            blocks: [
                {
                    padding: '37px',
                    imgs: [{
                        src: '/img4/wheel_bg@3x.png',
                        width: '94.8%',
                        height: '97.8%',
                        rotate: false
                    }]
                },
                {
                    padding: '60px',
                    imgs: [{
                        src: '/img4/wheel@2x.png',
                        width: '100%',
                        height: '100%',
                        rotate: true
                    }]
                }
            ],
            prizes: [
                {
                    title: '20啵币',
                    index: 0,
                    // fonts: [{ text: '0',fontSize: '12px' }],
                    // background: '#e9e8fe'
                },
                {
                    title: '小爱同学蓝牙音箱',
                    index: 1,
                    // fonts: [{ text: '1',fontSize: '12px' }],
                    // background: '#b8c5f2'
                },
                {
                    title: '68元平台彩金',
                    index: 2,
                    // fonts: [{ text: '2',fontSize: '12px' }],
                    // background: '#e9e8fe'
                },
                {
                    title: '50啵币',
                    index: 3,
                    // fonts: [{ text: '3',fontSize: '12px' }],
                    // background: '#b8c5f2'
                },
                {
                    title: 'iPhone13 pro max 256G',
                    index: 4,
                    // fonts: [{ text: '4',fontSize: '12px' }],
                    // background: '#e9e8fe'
                },
                {
                    title: '888元平台彩金',
                    index: 5,
                    // fonts: [{ text: '5',fontSize: '12px' }],
                    // background: '#b8c5f2'
                },
                {
                    title: '188啵币',
                    index: 6,
                    // fonts: [{ text: '6',fontSize: '12px' }],
                    // background: '#e9e8fe'
                },
                {
                    title: 'SK-II神仙水套装',
                    index: 7,
                    // fonts: [{ text: '7',fontSize: '12px' }],
                    // background: '#b8c5f2'
                },
                {
                    title: '188元平台彩金',
                    index: 8,
                    // fonts: [{ text: '8',fontSize: '12px' }],
                    // background: '#e9e8fe'
                },
                {
                    title: '5啵币',
                    index: 9,
                    // fonts: [{ text: '9',fontSize: '12px' }],
                    // background: '#b8c5f2'
                },
                {
                    title: '苹果手表S6',
                    index: 10,
                    // fonts: [{ text: '10',fontSize: '12px' }],
                    // background: '#e9e8fe'
                },
                {
                    title: '18元平台彩金',
                    index: 11,
                    // fonts: [{ text: '11',fontSize: '12px' }],
                    // background: '#b8c5f2'
                }
            ],
            buttons: [
                {
                    radius: '50%',
                    imgs: [{
                        src: '/img4/button@2x.png',
                        width: '100%',
                        top: '-130%'
                    }]
                }
            ],
            defaultConfig: {
                offsetDegree: 15,
                stopRange: 0.5,
                speed: 25
            },
            defaultStyle: {

            },
            // http_param: "1460114852155490304-6b54726f1256d8bdf3a583cd92da600f",
            http_param: "",
            luckyNum: 0,
            prize_type: 0,
            dialog_value: false,
            rule_active: false,
            winning_list1: [
                // { createTime: '2021-01-01 00:00:00', luckyName: '10啵币' },
                // { createTime: '2021-01-01 00:00:00', luckyName: '888元平台彩金' },
                // { createTime: '2021-01-01 00:00:00', luckyName: '小爱同学蓝牙音箱' },
                // { createTime: '2021-01-01 00:00:00', luckyName: 'iPhone13 pro max 256G' },
                // { createTime: '2021-01-01 00:00:00', luckyName: '小爱同学蓝牙音箱' },
                // { createTime: '2021-01-01 00:00:00', luckyName: '50啵币' }
            ],
            winning_list2: [

            ],
            isLogin: 'yes',
            codeType: 200
        }
    },
    created() {
        this.gongGeMyInfo2();
    },
    mounted() {

    },
    methods: {
        servier() {
            window.open("https://chat.onechat.one/?channelId=B6b1xN");
        },
        goAppPc() {
            if ((navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i))) {
                return 'APP'
            }
            else {
                return 'PC'
            }
        },
        recordPcList() {
            let params = {
                pageNumber: 1,
                pageSize: 10
            }
            recordPcList(params, this.$route.query.token).then((res) => {
                console.log("--recordPcList--", res)
                this.winning_list1 = [];
                this.winning_list2 = [];
                if (res.data.code == 200) {

                    for(let i = 0; i < res.data.data.list.length; i++) {
                        if(i % 2 == 0){
                            this.winning_list1.push({
                                createTime: this.timeTransformation(res.data.data.list[i].createTime),
                                luckyName: res.data.data.list[i].luckyName
                            })
                        }else if(i % 2 == 1){
                            this.winning_list2.push({
                                createTime: this.timeTransformation(res.data.data.list[i].createTime),
                                luckyName: res.data.data.list[i].luckyName
                            })
                        }
                    }
                    
                }
                    
            })
        },
        timeTransformation(time) {
            let date = new Date(time*1000);
            let YY = date.getFullYear() + '-';
            let MM = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
            let DD = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
            let hh = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
            let mm = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
            let ss = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
            return YY+MM + DD +" " + hh +mm + ss
        },
        ruleOpen() {
            this.rule_active = true;
        },
        gongGeMyInfo2() {
            let that = this;
            let param = {
                token: that.$route.query.token ? that.$route.query.token : that.http_param
            }
            gongGeMyInfo2(param).then((res) => {
                console.log('---gongGeMyInfo2----', res);
                if (res.data.code == 200) {
                    that.luckyNum = res.data.data.num;
                    that.recordPcList();
                } else if(res.data.code == 600001) {
                    that.isLogin = 'no'
                } else if(res.data.code == 500) {
                    that.codeType = 500;
                } else if(res.data.code == 501) {
                    that.codeType = 501;
                }
            }).catch(() => {

            });
        },
        startCallBack() {
            let that = this;
            if(that.isLogin == 'no') {
                that.prize_type = 404;
                that.dialog_value = true;
                return
            } else if (that.codeType == 500) {
                that.prize_type = 500;
                that.dialog_value = true;
                return
            } else if (that.codeType == 501) {
                that.prize_type = 501;
                that.dialog_value = true;
                return
            } else if (that.luckyNum == 0) {
                that.prize_type = 520;
                that.dialog_value = true;
                return
            }
            
            let param = {
                token: that.$route.query.token ? that.$route.query.token : that.http_param
            }
            startGongGe2(param).then((res) => {
                console.log('---startGongGe2---', res);
                if (res.data.code == 200) {
                    that.$refs.myLucky.play();
                    setTimeout(() => {
                        // let numstop = Math.random() * 7 >> 0;
                        let numstop = res.data.data.awardItem.type;
                        that.prize_type = numstop;
                        console.log('---stop----', numstop);
                        that.$refs.myLucky.stop(numstop);
                    }, 4000);
                } else if(res.data.code == 600001) {
                    that.prize_type = 404;
                    that.dialog_value = true;
                } else if(res.data.code == 500) {
                    that.prize_type = 500;
                    that.dialog_value = true;
                } else if(res.data.code == 501) {
                    that.prize_type = 501;
                    that.dialog_value = true;
                }
            }).catch(() => {

            });

        },
        endCallBack(prize) {
            this.gongGeMyInfo2();
            this.recordPcList();
            setTimeout(() => {
                this.dialog_value = true;
            }, 1000);
            console.log('---endCallBack---', prize);
        },
        cancelPrize() {
            this.dialog_value = false;
        }
    }
}
</script>

<style lang="scss" scoped>
#turntable {
    width: 100%;
    height: 1080px;
    overflow: hidden;
    -background: url('/img5/bg.png');
    background-image: image-set(url("/img5/bg.png") 1x, url("/img5/bg@2x.png") 2x);
    background-repeat: no-repeat;
    background-size: 100% 100%;
    position: relative;
    .robot-box {
        width: 330px;
        height: 290px;
        position: absolute;
        left: 50%;
        top: 540px;
        margin-left: 90px;
        .speak {
            padding: 6px 18px 0px 10px;
            box-sizing: border-box;
            height: 50px;
            background-image: image-set(url("/img5/speak.png") 1x, url("/img5/speak@2x.png") 2x);
            background-repeat: no-repeat;
            background-size: 100% 100%;
            font-size: 14px;
            line-height: 45px;
            color: #747681;
            position: absolute;
            right: 160px;
            top: 190px;
            span {
                color: #E32626;
            }
        }
        .robot {
            width: 200px;
            position: absolute;
            right: 0px;
            top: 0px;
        }
    }
    
    .lucky-wheel {
        position: absolute;
        left: 50%;
        top: 230px;
        margin-left: -266px;
    }
    .every-day {
        width: 490px;
        height: 225px;
        position: absolute;
        left: 50%;
        top: 15px;
        margin-left: -245px;
        z-index: 2;
        background-image: image-set(url("/img5/bg_words.png") 1x, url("/img5/bg_words@2x.png") 2x);
        background-repeat: no-repeat;
        background-size: 100% 100%;
        .servicio {
            width: 120px;
            position: absolute;
            right: -32%;
            top: 15px;
            margin-left: -60px;
            z-index: 2;
        }
    }
    .winning-record {
        width: 946px;
        height: 247px;
        position: absolute;
        left: 50%;
        top: 820px;
        margin-left: -473px;
        background-image: image-set(url('/img5/explain.png') 1x,url('/img5/explain@2x.png') 2x);
        background-repeat: no-repeat;
        background-size: 100% 100%;
        padding: 20px 40px 0 40px;
        box-sizing: border-box;
        .mercury {
            width: 80px;
            height: 32px;
            line-height: 32px;
            color: #999999;
            background: #003D99;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            position: absolute;
            left: 3px;
            top: -30px;
        }
        .title-box {
            width: 100%;
            height: 35px;
            line-height: 20px;
            img {
                width: 199px;
                margin: 0 auto;
            }
        }
        .winning-list {
            width: 100%;
            height: 145px;
            /deep/.el-scrollbar__wrap {
                overflow-x: hidden;
            }
            ul {
                width: 42%;
                height: 100%;
                float: left;
                padding: 0;
                margin: 0;
                li {
                    width: 100%;
                    height: 32px;
                    float: left;
                    color: #999999;
                    font-size: 14px;
                    text-align: left;
                    line-height: 32px;
                    font-weight: normal;
                    span:nth-of-type(1){
                        float: left;
                    }
                    span:nth-of-type(2){
                        float: right;
                        display: inline-block;
                        width: 48%;
                        height: 100%;
                    }
                }
            }
            ul:nth-of-type(2) {
                float: right;
            }
        }
        p {
            width: 100%;
            height: 32px;
            margin: 0;
            padding: 0;
            color: #2F2985;
            text-align: center;
            line-height: 42px;
            font-size: 15px;
            font-weight: 600;
        }
        .pic-nohistory {
            width: 140px;
            position: absolute;
            left: 390px;
            top: 55px;
        }
    }
    /deep/ .van-dialog {
      background: none;
      .van-dialog__header {
        display: none;
      }
      .van-dialog__content {
        .prize-box {
            height: 260px;
            position: relative;
            .dialog-envelopes {
                width: 100%;
                position: absolute;
                left: 0px;
                top: 0px;
            }
            .thank-you {
                width: 100%;
                text-align: center;
                font-size: 15px;
                color: #7B98EA;
                position: absolute;
                left: 0px;
                top: 90px;
            }
            .dialog-cancel {
                width: 120px;
                position: absolute;
                left: 112.5px;
                top: 125px;
            }
        }
      }
      .van-dialog__footer {
        display: none;
      }
    }

    /deep/ .el-dialog {
        .el-dialog__header {
            padding: 0;
            height: 50px;
            text-align: left;
            line-height: 50px;
            span {
                margin: 14px 0 0 20px;
                float: left;
            }
            button {
                float: right;
                height: 16px;
                line-height: 16px;
            }
        }
        .el-dialog__body {
            padding: 0;
            .rule-box {
                width: 100%;
                height: 230px;
                position: relative;
                .activity-description {
                    width: 100%;
                    height: 100%;
                    padding: 0 30px;
                    box-sizing: border-box;
                    margin: 0;
                    li {
                        width: 100%;
                        float: left;
                        padding: 5px 0;
                        box-sizing: border-box;
                        color: #002CCE;
                        font-size: 14px;
                        text-align: left;
                        line-height: 28px;
                        font-weight: normal;
                    }
                }
            }
        }
        .el-dialog__footer {
            padding: 0;
            height: 70px;
            line-height: 0px;
            display: flex;
            align-items: center; // 垂直-对齐方式
            justify-content: center;
        }
    }
}
</style>


