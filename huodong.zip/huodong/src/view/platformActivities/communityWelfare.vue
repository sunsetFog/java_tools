<template>
    <section id="communityWelfare">
        <div class="banner">
            <img :src="appHeadImg"/>
        </div>
        <div class="cosplay">
            <a :href="kefu">联系客服</a>
        </div>
        <section class="cartoon" v-for="(item,index) in tableRule" :key="index">
            <div class="activity-type">
                <div class="activity-title">
                    <div class="left-icon"></div>
                    {{item.activity_title}}
                    <div class="right-icon"></div>
                </div>
            </div>
            <div class="surface">
                <table v-html="item.tableContent">
                    
                </table>
            </div>
            <div class="activity-rules" v-html="item.ruleContent">

            </div>
        </section>
    </section>
</template>

<script>
import { welfareDetails, templateList, gitConfig } from '@/api/home'
export default {
    name: "communityWelfare",
    data() {
        return {
            appHeadImg: '',
            kefu: 'https://chat.onechat.one/?channelId=B6b1xN',
            tableRule: [
                // { 
                //     activity_title: '首存活动',
                //     ruleContent: '<ul><li>活动规则：</li><li>1. c从vv三六零</li><li>2. 出口处了</li></ul>',
                //     tableContent: '<thead style=background:url(/platform/4/tbg.png);color:#161B1C><tr><th>尺寸</th><th>都市</th></tr></thead><tbody><tr><td>1</td><td>2</td></tr><tr><td>3</td><td>4</td></tr></tbody>'
                // },
                // { 
                //     activity_title: '首存活动',
                //     ruleContent: '<ul><li>活动规则：</li><li>1. c从vv三六零</li><li>2. 出口处了</li></ul>',
                //     tableContent: '<thead style=background:url(/platform/4/tbg.png);color:#161B1C><tr><th>尺寸</th><th>都市</th></tr></thead><tbody><tr><td>1</td><td>2</td></tr><tr><td>3</td><td>4</td></tr></tbody>'
                // }
            ]
        }
    },
    created() {
        this.getJson()
    },
    methods: {
        getJson() {
            let that = this;
            let params = {
                id: that.$route.query.id ? that.$route.query.id : -1
            }
            welfareDetails(params).then(res => {
                console.log('--welfareDetails--', res.data)
                if(res.data.code != 200) {
                    return
                }
                that.appHeadImg = res.data.data.entranceImgApp;
                let list = res.data.data.contentMode == 0 ? res.data.data.welfareActivities : res.data.data.welfareCustomActivities;
                that.tableRule = [];
                for (let i = 0; i < list.length; i++) {
                    let season = res.data.data.contentMode == 0 ? list[i].appDetail : list[i].activityContent
                    let str = season.match(/<tbody><tr><th>(\S*)tbody/);
                    if (str) {
                        str = str[1].split('</th></tr>')
                        str = '<thead style=background:url(/platform/4/tbg.png);color:#161B1C><tr><th>' + str[0] + '</th></tr></thead>' + '<tbody>' + str[1] + 'tbody>'
                    }

                    let wee = season.match(/<ol>(\S*)ol>/);
                    if (wee) {
                        wee = wee[1].substring(0,wee[1].length-2);

                        console.log(1111, wee);
                        wee = wee.split('<li>');
                        console.log(2222, wee);
                        let indexwill = ''
                        for (let i = 0; i < wee.length; i++) {
                            if (wee[i]) {
                                indexwill += '<li>' + i + '. ' + wee[i]
                            }
                        }
                        console.log(3333, indexwill);
                        wee =  '<ul><li>活动规则：</li>' + indexwill + '</ul>';
                    }
                    that.tableRule.push({ 
                        activity_title: list[i].activityTitle,
                        tableContent: str,
                        ruleContent: wee
                    })
                }
                console.log('--list--', list);
                console.log('--tableRule--', that.tableRule);
            })
        },
        timeTransformation(time) {
            let date = new Date(time*1000);
            let YY = date.getFullYear() + '-';
            let MM = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
            let DD = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
            // let hh = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
            // let mm = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
            // let ss = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
            return YY + '年' + MM + '月' + DD + '日'
        }
    }
}
</script>

<style lang="scss" scoped>
#communityWelfare {
    width: 100%;
    min-height: 100%;
    -background: #fff;
    background: #090808;
    padding: 0 0 15px 0;
    box-sizing: border-box;
    .banner {
        width: 100%;
        height: 135px;
        padding: 15px 15px 10px 15px;
        box-sizing: border-box;
        img {
            width: 100%;
            height: 100%;
        }
    }
    .cosplay {
        width: 100%;
        height: 60px;
        display: flex;
        align-items: center;
        justify-content: center;
        a {
            width: 190px;
            height: 40px;
            line-height: 40px;
            border-radius: 5px;
            font-size: 13.5008px;
            color: #161B1C;
            display: inline-block;
            text-decoration: none;
            background-image: image-set(url("/platform/4/kefu.png") 1x, url("/platform/4/kefu@2x.png") 2x);
            background-repeat: no-repeat;
            background-size: 100% 100%;
        }
    }
    .cartoon {
        width: 345px;
        margin: 10px auto 0px auto;
        -border: 1px solid #E2E7F2;
        border-radius: 8px;
        overflow: hidden;
        .activity-type {
            width: 100%;
            height: 50px;
            line-height: 50px;
            padding: 9px 20px;
            box-sizing: border-box;
            display: flex;
            align-items: center;
            justify-content: center;
            .activity-title {
                height: 100%;
                line-height: 32px;
                padding: 0 10px;
                box-sizing: border-box;
                font-size: 14px;
                font-weight: 700;
                color: #F1D5B9;
                position: relative;
                .left-icon {
                    width: 40px;
                    height: 35px;
                    background-image: image-set(url("/platform/4/left_ball.png") 1x, url("/platform/4/left_ball@2x.png") 2x);
                    background-repeat: no-repeat;
                    background-size: 100% 100%;
                    position: absolute;
                    left: -45px;
                    top: 0px;
                }
                .right-icon {
                    width: 55px;
                    height: 55px;
                    background-image: image-set(url("/platform/4/right_ball.png") 1x, url("/platform/4/right_ball@2x.png") 2x);
                    background-repeat: no-repeat;
                    background-size: 100% 100%;
                    position: absolute;
                    right: -60px;
                    top: 0px;
                }
            }
        }
        .surface {
            width: 100%;
            border-radius: 9.92px;
            padding: 8px 1px 10px 1px;
            box-sizing: border-box;
            /deep/ table {
                width: 100%;
                border-collapse: collapse;
                border-radius: 9.92px;
                border: 1px solid #784F2C;
                border-style: hidden;// 消除掉外边框
                box-shadow: 0 0 0 1px #784F2C;
                overflow: hidden;
            }
            /deep/ th, /deep/ td {
                border: 1px solid #784F2C;
                padding: 5px;
                box-sizing: border-box;
            }
            /deep/ thead th {
                height: 48px;
                font-weight: 400;
                font-size: 14px;
            }
            /deep/ thead {
                background-repeat: no-repeat !important;
                background-size: 100% 100% !important;
            }
            /deep/ tbody td {
                height: 40px;
                font-size: 13px;
                color: #F2F2F2;
            }
            /deep/ p {
                margin: 0;
                padding: 0;
            }
        }
        .activity-rules {
            width: 100%;
            padding: 8px 1px 25px 1px;
            box-sizing: border-box;
            /deep/ ul {
                width: 100%;
                margin: 0;
            }
            /deep/ li {
                width: 100%;
                padding: 6.4px 0 0 0;
                box-sizing: border-box;
                text-align: left;
                font-size: 13.5008px;
                -list-style-type: decimal;
                color: #E6C9AA;
            }
            /deep/ li:nth-of-type(1) {
                font-weight: 600;
            }
        }

    }
}
</style>


