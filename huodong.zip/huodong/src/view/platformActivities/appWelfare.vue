<template>
    <section id="appWelfare">
        <div class="banner" :style="{backgroundImage:'url(' + appHeadImg + ')'}">
            <a :href="kefu" class="kefu">联系客服</a>
            <a :href="guanwang" class="guanwang">登录官网</a>
        </div>
        <section class="cartoon" v-for="(item,index) in tableRule" :key="index">
            <div class="activity-type">
                <div class="left-icon"></div>
                <div class="activity-title">{{item.activity_title}}</div>
                <div class="right-icon"></div>
            </div>
            <div class="surface">
                <table v-html="item.tableContent">
                    
                </table>
            </div>
            <div class="activity-rules" v-html="item.ruleContent">

            </div>
        </section>
    </section>
</template>

<script>
import { mercury, templateList, gitConfig } from '@/api/home'
export default {
    name: "appWelfare",
    data() {
        return {
            appHeadImg: '',
            guanwang: '',
            kefu: '',
            tableRule: [
                { 
                    activity_title: '',
                    tableContent: '',
                    ruleContent: ''
                }
            ]
        }
    },
    created() {
        this.getJson()
        // this.officialWay()
    },
    methods: {
        gitConfigList() {
            let that = this;
            let params = {
                communityId: that.$route.query.communityId ? that.$route.query.communityId : "",
                inviteCode: that.$route.query.inviteCode ? that.$route.query.inviteCode : ""
            }
            if (that.$route.query.communityId) {
                gitConfig(params).then(res => {
                    let headerList = res.data.data
                    headerList.h5_url&&that.$set(that, 'guanwang', headerList.h5_url)

                    var kefu101 = "tencent://message/?uin=" + headerList.qq + "&Site=&Menu-=yes";
                    var kefu102 = "mqqwpa://im/chat?chat_type=wpa&uin=" + headerList.qq + "&version=1&src_type=web&web_src=oicqzone.com";
                    if (headerList.qq) {
                        let regqq = that.checkInstalled('qq')
                        if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent) || /(Android)/i.test(navigator.userAgent)) {
                        that.$set(that, 'kefu', regqq?kefu102:'https://im.qq.com/immobile/index.html')
                        } else {
                        that.$set(that, 'kefu', regqq?kefu101:'https://im.qq.com/immobile/index.html')
                        }
                    }
                })
            }
        },
        checkInstalled(m) {  
            switch(m){
                case 'msn':  
                try {  
                    new ActiveXObject("MSNMessenger.P4QuickLaunch");  
                    return true;  
                }  
                catch (e) {  
                    return false;  
                }  
                case 'qq':  
                try {  
                    new ActiveXObject("TimwpDll.TimwpCheck");  
                    return true;  
                }  
                catch (e) {  
                    return false;  
                }
                case 'skype':  
                try{  
                    new ActiveXObject("Skype.Detection");  
                    return true;  
                }catch(e){  
                    return false;  
                } 

            }  
        },
        // officialWay() {
        //     let that = this;
        //     let params = {
        //         id: that.$route.query.id ? that.$route.query.id : -1, // 42
        //         userId: that.$route.query.userId ? that.$route.query.userId : ''
        //     }
        //     templateList(params).then(res => {
        //         that.guanwang = res.data.data.template.gwJumpForH5;
        //         that.kefu = res.data.data.template.kefuJump;
        //         that.gitConfigList();
        //     })
        // },
        getJson() {
            let that = this;
            let params = {
                communityId: that.$route.query.communityId ? that.$route.query.communityId : "",// 1372817666300968960
                userId: that.$route.query.userId ? that.$route.query.userId : ''
            }
            mercury(params).then(res => {
                console.log('--mercury--', res.data)
                if(res.data.code != 200) {
                    return
                }
                that.guanwang = res.data.data.gwJump;
                that.kefu = res.data.data.kefuJump;

                that.appHeadImg = res.data.data.entranceImgApp;
                let list = res.data.data.contentMode == 0 ? res.data.data.welfareActivities : res.data.data.welfareCustomActivities;
                that.tableRule = [];
                for (let i = 0; i < list.length; i++) {
                    if(list[i].activityType == '1') {
                        continue;
                    }
                    let season = res.data.data.contentMode == 0 ? list[i].appDetail : list[i].activityContent
                    let str = season.match(/<tbody><tr><th>(\S*)tbody/);
                    if (str) {
                        str = str[1].split('</th></tr>')
                        str = '<thead style=background:#368CFB;color:#fff><tr><th>' + str[0] + '</th></tr></thead>' + '<tbody>' + str[1] + 'tbody>'
                    }

                    let wee = season.match(/<ol>(\S*)ol>/);
                    if (wee) {
                        wee = wee[1].substring(0,wee[1].length-2);

                        console.log(1111, wee);
                        wee = wee.split('<li>');
                        console.log(2222, wee);
                        let indexwill = ''
                        for (let i = 0; i < wee.length; i++) {
                            if (wee[i]) {
                                indexwill += '<li>' + i + '. ' + wee[i]
                            }
                        }
                        console.log(3333, indexwill);
                        wee =  '<ul><li>活动规则：</li>' + indexwill + '</ul>';
                    }
                    that.tableRule.push({ 
                        activity_title: list[i].activityTitle,
                        tableContent: str,
                        ruleContent: wee
                    })
                }
                console.log('--list--', list);
                console.log('--tableRule--', that.tableRule);
                that.gitConfigList();
            })
        },
        timeTransformation(time) {
            let date = new Date(time*1000);
            let YY = date.getFullYear() + '-';
            let MM = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
            let DD = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
            // let hh = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
            // let mm = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
            // let ss = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
            return YY + '年' + MM + '月' + DD + '日'
        }
    }
}
</script>

<style lang="scss" scoped>
#appWelfare {
    width: 100%;
    min-height: 100%;
    background: #fff;
    padding: 0 0 0.9375rem 0;
    box-sizing: border-box;
    .banner {
        width: 100%;
        height: 14.375rem;
        -background-image: image-set(url("/platform/2/banner.png") 1x, url("/platform/2/banner@2x.png") 2x, url("/platform/2/banner@3x.png") 3x);
        background-repeat: no-repeat;
        background-size: 100% 100%;
        position: relative;
        a {
            width: 4.375rem;
            height: 1.875rem;
            line-height: 1.875rem;
            border-radius: 0.625rem;
            position: absolute;
            background-repeat: no-repeat;
            background-size: 100% 100%;
            font-size: 0.8438rem;
            text-decoration: none;
        }
        .kefu {
            color: #fff;
            right: 5.625rem;
            bottom: 0.625rem;
            background-image: image-set(url("/platform/2/kefu.png") 1x, url("/platform/2/kefu@2x.png") 2x);
        }
        .guanwang {
            color: #70A0F4;
            right: 0.625rem;
            bottom: 0.625rem;
            background-image: image-set(url("/platform/2/guanwang.png") 1x, url("/platform/2/guanwang@2x.png") 2x);
        }
    }
    .cartoon {
        width: 21.5625rem;
        margin: 0.625rem auto 0rem auto;
        border: 0.0625rem solid #E2E7F2;
        border-radius: 0.5rem;
        overflow: hidden;
        .activity-type {
            width: 100%;
            height: 3.125rem;
            line-height: 3.125rem;
            display: flex;
            padding: 0.5625rem 1.25rem;
            box-sizing: border-box;
            .left-icon {
                flex: 1;
                height: 0.625rem;
                margin: 0.75rem 0 0 0;
                background-image: image-set(url("/platform/2/leftIcon.png") 1x, url("/platform/2/leftIcon@2x.png") 2x);
                background-repeat: no-repeat;
                background-size: 100% 100%;
            }
            .activity-title {
                height: 100%;
                line-height: 2rem;
                padding: 0 0.625rem;
                box-sizing: border-box;
                margin: 0 0.625rem;
                font-size: 0.875rem;
                font-weight: 700;
                color: #C19860;
                background-image: image-set(url("/platform/2/title.png") 1x, url("/platform/2/title@2x.png") 2x);
                background-repeat: no-repeat;
                background-size: 100% 100%;
            }
            .right-icon {
                flex: 1;
                height: 0.625rem;
                margin: 0.75rem 0 0 0;
                background-image: image-set(url("/platform/2/rightIcon.png") 1x, url("/platform/2/rightIcon@2x.png") 2x);
                background-repeat: no-repeat;
                background-size: 100% 100%;
            }
        }
        .surface {
            width: 100%;
            border-radius: 0.62rem;
            background: white;
            padding: 0.5rem 0.5rem 0.625rem 0.5rem;
            box-sizing: border-box;
            /deep/ table {
                width: 100%;
                border-collapse: collapse;
                border-radius: 0.62rem;
                border: 0.0625rem solid #ECECEC;
                border-style: hidden;// 消除掉外边框
                box-shadow: 0 0 0 0.0625rem #ECECEC;
                overflow: hidden;
            }
            /deep/ th, /deep/ td {
                border: 0.0625rem solid #ECECEC;
                padding: 0.3125rem;
                box-sizing: border-box;
            }
            /deep/ thead th {
                height: 3rem;
                font-weight: 400;
                font-size: 0.875rem;
            }
            /deep/ tbody td {
                height: 2.5rem;
                font-size: 0.8125rem;
            }
            /deep/ p {
                margin: 0;
                padding: 0;
            }
        }
        .activity-rules {
            width: 100%;
            background: white;
            padding: 0.5rem 0.5rem 1.5625rem 0.5rem;
            box-sizing: border-box;
            /deep/ ul {
                width: 100%;
                margin: 0;
            }
            /deep/ li {
                width: 100%;
                padding: 0.4rem 0 0 0;
                box-sizing: border-box;
                text-align: left;
                font-size: 0.8438rem;
                -list-style-type: decimal;
            }
            /deep/ li:nth-of-type(1) {
                font-weight: 600;
            }
        }

    }
}
</style>


