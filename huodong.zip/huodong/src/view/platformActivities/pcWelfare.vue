<template>
    <section id="pcWelfare">
        <section class="box-center">
            <!-- <div class="banner" :style="{backgroundImage:'url(' + appHeadImg + ')'}">

            </div>
            <div class="official">
                <img class="logo" :src="communityLogo" alt="">
                <span class="sports-name">{{communityName}}</span>
                <a :href="guanwang">
                    <img src="/platform/3/guanwang.png" srcset="/platform/3/guanwang@2x.png 2x" alt="">
                    <span>进入官网</span>
                </a>
                <a :href="kefu">
                    <img src="/platform/3/service.png" srcset="/platform/3/service@2x.png 2x" alt="">
                    <span>联系客服</span>
                </a>
            </div> -->
            <section class="cartoon" v-for="(item,index) in tableRule" :key="index">
                <div class="title-img" :id="'card'+index">
                    <img :src="'/formwork/pc/card' + (index + 1) + '.png'" alt="">
                    <label>{{item.activity_title}}</label>
               </div>
               <div class="surface">
                    <table v-html="item.tableContent">
                        
                    </table>
                </div>
                <div class="activity-rules">
                    <div class="arrowhead">
                        <div>
                            <img src="/formwork/pc/jiantou.png"/>
                            活动说明
                            <img src="/formwork/pc/jiantou.png"/>
                        </div>
                    </div>
                    <div v-html="item.ruleContent"></div>
                </div>
            </section>
        </section>
    </section>
</template>

<script>
import { pcWelfareDetails, gitConfig } from '@/api/home'
export default {
    name: "pcWelfare",
    data() {
        return {
            appHeadImg: '',
            guanwang: '',
            kefu: '',
            communityLogo: '',
            communityName: '',
            tableRule: [
                { 
                    activity_title: '',
                    tableContent: '',
                    ruleContent: ''
                }
            ]
        }
    },
    created() {
        this.getJson()
        // this.officialWay()
    },
    methods: {
        gitConfigList() {
            let that = this;
            let params = {
                communityId: that.$route.query.communityId ? that.$route.query.communityId : "",
                inviteCode: that.$route.query.inviteCode ? that.$route.query.inviteCode : ""
            }
            if (that.$route.query.communityId) {
                gitConfig(params).then(res => {
                    let headerList = res.data.data
                    headerList.h5_url&&that.$set(that, 'guanwang', headerList.h5_url)

                    var kefu101 = "tencent://message/?uin=" + headerList.qq + "&Site=&Menu-=yes";
                    var kefu102 = "mqqwpa://im/chat?chat_type=wpa&uin=" + headerList.qq + "&version=1&src_type=web&web_src=oicqzone.com";
                    if (headerList.qq) {
                        let regqq = that.checkInstalled('qq')
                        if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent) || /(Android)/i.test(navigator.userAgent)) {
                        that.$set(that, 'kefu', regqq?kefu102:'https://im.qq.com/immobile/index.html')
                        } else {
                        that.$set(that, 'kefu', regqq?kefu101:'https://im.qq.com/immobile/index.html')
                        }
                    }
                })
            }
        },
        checkInstalled(m) {  
            switch(m){
                case 'msn':  
                try {  
                    new ActiveXObject("MSNMessenger.P4QuickLaunch");  
                    return true;  
                }  
                catch (e) {  
                    return false;  
                }  
                case 'qq':  
                try {  
                    new ActiveXObject("TimwpDll.TimwpCheck");  
                    return true;  
                }  
                catch (e) {  
                    return false;  
                }
                case 'skype':  
                try{  
                    new ActiveXObject("Skype.Detection");  
                    return true;  
                }catch(e){  
                    return false;  
                } 

            }  
        },
        // officialWay() {
        //     let that = this;
        //     let params = {
        //         id: that.$route.query.id ? that.$route.query.id : -1, // 42
        //         userId: that.$route.query.userId ? that.$route.query.userId : ''
        //     }
        //     templateList(params).then(res => {
        //         that.guanwang = res.data.data.template.gwJumpForH5;
        //         that.kefu = res.data.data.template.kefuJump;
        //         that.communityLogo = res.data.data.template.communityLogo;
        //         that.gitConfigList();
        //     })
        // },
        getJson() {
            let that = this;
            let params = {
                id: that.$route.query.welfareId ? that.$route.query.welfareId : "",
                userId: that.$route.query.userId ? that.$route.query.userId : ''
            }
            pcWelfareDetails(params).then(res => {
                console.log('--pcWelfareDetails--', res.data)
                if(res.data.code != 200) {
                    return
                }
                that.guanwang = res.data.data.gwJump;
                that.kefu = res.data.data.kefuJump;
                that.communityLogo = res.data.data.communityLogo;

                that.appHeadImg = res.data.data.entranceImgPc;
                that.communityName = res.data.data.communityName;
                let list = res.data.data.contentMode == 0 ? res.data.data.welfareActivities : res.data.data.welfareCustomActivities;
                that.tableRule = [];
                for (let i = 0; i < list.length; i++) {
                    if(list[i].activityType == '0') {
                        continue;
                    }
                    let season = res.data.data.contentMode == 0 ? list[i].pcDetail : list[i].activityContent
                    let str = season.match(/<tbody><tr><th>(\S*)tbody/);
                    if (str) {
                        str = str[1].split('</th></tr>')
                        str = '<thead style=background:#368CFB;color:#fff><tr><th>' + str[0] + '</th></tr></thead>' + '<tbody>' + str[1] + 'tbody>'
                    }

                    let wee = season.match(/<ol>(\S*)ol>/);
                    if (wee) {
                        wee = wee[1].substring(0,wee[1].length-2);

                        console.log(1111, wee);
                        wee = wee.split('<li>');
                        console.log(2222, wee);
                        let indexwill = ''
                        for (let i = 0; i < wee.length; i++) {
                            if (wee[i]) {
                                indexwill += '<li>' + i + '. ' + wee[i]
                            }
                        }
                        console.log(3333, indexwill);
                        wee =  '<ul>' + indexwill + '</ul>';
                    }
                    that.tableRule.push({ 
                        activity_title: list[i].activityTitle,
                        tableContent: str,
                        ruleContent: wee
                    })
                }
                console.log('--list--', list);
                console.log('--tableRule--', that.tableRule);
                that.gitConfigList();
            })
        },
        timeTransformation(time) {
            let date = new Date(time*1000);
            let YY = date.getFullYear() + '-';
            let MM = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
            let DD = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
            // let hh = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
            // let mm = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
            // let ss = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
            return YY + '年' + MM + '月' + DD + '日'
        }
    }
}
</script>

<style lang="scss" scoped>
#pcWelfare {
    .box-center {
        width: 950px;
        min-height: 850px;
        background: #fff;
        margin: 0px auto;
        padding: 15px 45px 20px 45px;
        box-sizing: border-box;
        .banner {
            width: 100%;
            height: 360px;
            -background-image: image-set(url("/platform/1/banner.png") 1x, url("/platform/1/banner@2x.png") 2x, url("/platform/1/banner@3x.png") 3x);
            background-repeat: no-repeat;
            background-size: 100% 100%;
            position: relative;
            span {
                color: #fff;
                font-size: 13px;
                position: absolute;
                left: 50px;
                bottom: 73px;
            }
        }
        .official {
            width: 100%;
            height: 85px;
            font-size: 14.4px;
            padding: 10px 0 10px 0;
            box-sizing: border-box;
            position: relative;
            .logo {
                height: 110px;
                border-radius: 50%;
                position: absolute;
                left: 25px;
                top: -35px;
                z-index: 5;
            }
            .sports-name {
                font-size: 16px;
                font-weight: 600;
                position: absolute;
                left: 150px;
                top: 16px;
            }
            a {
                width: 100px;
                color: #fff;
                height: 32px;
                line-height: 30px;
                font-size: 14px;
                text-decoration: none;
                border-radius: 5px;
                img {
                    width: 16px;
                    height: 16px;
                }
                span {
                    vertical-align: middle;
                    margin-left: 4.8px;
                }
            }
            a:nth-of-type(1) {
                background: #3069F6;
                position: absolute;
                right: 110px;
                top: 10px;
            }
            a:nth-of-type(2) {
                background: #FF6C21;
                position: absolute;
                right: 0px;
                top: 10px;
            }
        }
        .cartoon {
            width: 100%;
            .title-img {
                width: 100%;
                height: 70px;
                margin: 10px 0;
                position: relative;
                img {
                    width: 410px;
                    height: 70px;
                    position: absolute;
                    left: 0px;
                    top: 0px;
                }
                label {
                    color: #fff;
                    font-size: 14px;
                    font-weight: 600;
                    position: absolute;
                    left: 100px;
                    top: 30px;
                }
            }

            .surface {
                width: 100%;
                border-radius: 9.92px;
                padding: 8px 1px 10px 1px;
                box-sizing: border-box;
                /deep/ table {
                    width: 100%;
                    border-collapse: collapse;
                    border-radius: 9.92px;
                    border: 1px solid #ECECEC;
                    border-style: hidden;// 消除掉外边框
                    box-shadow: 0 0 0 1px #ECECEC;
                    overflow: hidden;
                }
                /deep/ th, /deep/ td {
                    border: 1px solid #ECECEC;
                    padding: 5px;
                    box-sizing: border-box;
                }
                /deep/ thead th {
                    height: 48px;
                    font-weight: 400;
                    font-size: 14px;
                }
                /deep/ tbody td {
                    height: 40px;
                    font-size: 13px;
                    color: #2c3e50;
                }
                /deep/ p {
                    margin: 0;
                    padding: 0;
                }
            }
            .activity-rules {
                width: 100%;
                padding: 8px 1px 25px 1px;
                box-sizing: border-box;
                /deep/ ul {
                    width: 100%;
                    margin: 0;
                }
                /deep/ li {
                    width: 100%;
                    padding: 6.4px 0 0 0;
                    box-sizing: border-box;
                    text-align: left;
                    font-size: 13.5008px;
                    -list-style-type: decimal;
                    color: #2c3e50;
                }
                .arrowhead {
                    width: 100%;
                    height: 50px;
                    line-height: 50px;
                    margin: 20px 0 20px 0;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    div {
                        width: 100px;
                        height: 100%;
                        font-weight: 600;
                        color: #3F74F7;
                        font-size: 15px;
                        position: relative;
                        img {
                            width: 80px;
                            height: 20px;
                        }
                        img:nth-of-type(1) {
                            position: absolute;
                            left: -80px;
                            top: 12px;
                        }
                        img:nth-of-type(2) {
                            transform: rotate(180deg);
                            position: absolute;
                            right: -80px;
                            top: 12px;
                        }
                    }
                    
                }
            } 
        }
    }
}
</style>


