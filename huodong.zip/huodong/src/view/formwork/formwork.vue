<template>
    <section id="formwork" v-if="JSON.stringify(activity_list) != '{}'">
        <div class="banner">
            <img v-if="activity_list.banner.length != 0" :src="activity_list.banner[0]" alt="">
        </div>

        <section class="cooperation">
            <section class="design-box">
                <p class="title">{{activity_list.title}}</p>
                <p class="score">
                    <span>{{activity_list.score.total}}分</span>
                    <span>出款速度：{{activity_list.score.disbursementSpeed}}&nbsp;&nbsp;&nbsp;综合评分：{{activity_list.score.comprehensive}}&nbsp;&nbsp;&nbsp;活动指数：{{activity_list.score.activityIndex}}</span>
                </p>
                <ul class="banner-list">
                    <li v-for="(item,index) in activity_list.banner" :key="index">
                        <viewer :images="activity_list.banner">
                            <img :src="item" alt="">
                        </viewer>
                    </li>
                </ul>
                <p class="activity_date">
                    <span>活动日期</span>
                    <span>{{activity_list.activityDate}}</span>
                </p>
                <div class="logo-box">
                    <dl>
                        <dt>
                            <img :src="activity_list.logo" alt="">
                        </dt>
                        <dd>{{activity_list.sportsName}}</dd>
                        <dd>近期玩家{{activity_list.recentPlayers}}+</dd>
                    </dl>
                    <ul>
                        <li>
                            <img src="../../../public/formwork/yabo/icon_tiyu.png" srcset="../../../public/formwork/yabo/icon_tiyu@2x.png 2x" alt="">
                            <span>体育</span>
                        </li>
                        <li>
                            <img src="../../../public/formwork/yabo/icon_dianjing.png" srcset="../../../public/formwork/yabo/icon_dianjing@2x.png 2x" alt="">
                            <span>电竞</span>
                        </li>
                        <li>
                            <img src="../../../public/formwork/yabo/icon_qipai.png" srcset="../../../public/formwork/yabo/icon_qipai@2x.png 2x" alt="">
                            <span>棋牌</span>
                        </li>
                    </ul>
                </div>
                <div class="official">
                    <a :href="activity_list.officialWebsite">
                        <img src="../../../public/formwork/yabo/icon_web.png" srcset="../../../public/formwork/yabo/icon_web@2x.png 2x" alt="">
                        <span>进入官网</span>
                    </a>
                    <a :href="activity_list.customerService">
                        <img src="../../../public/formwork/yabo/icon_lianxikefu.png" srcset="../../../public/formwork/yabo/icon_lianxikefu@2x.png 2x" alt="">
                        <span>联系客服</span>
                    </a>
                </div>
            </section>

            <section class="tab-box">
                <van-tabs v-model="van_active">
                    <template v-for="(firstItem,firstIndex) in activity_list.tabsTable">
                    <van-tab :title="firstItem.label" :key="firstIndex">
                        <table>
                            <thead :style="{ background: firstItem.theadStyle.backgroung, color: firstItem.theadStyle.color }">
                                <tr>
                                    <th v-for="(item,index) in firstItem.thead" :key="index">{{item}}</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(item,oneIndex) in firstItem.tbody" :key="oneIndex">
                                    <td  v-for="(val,twoIndex) in item" :key="twoIndex">{{val}}</td>
                                </tr>
                            </tbody>

                            <tfoot v-if="firstItem.tfoot.length != 0">
                                <tr>
                                    <td :colspan="firstItem.thead.length">
                                        <ul>
                                            <li>活动内容：</li>
                                            <li v-for="(item,index) in firstItem.tfoot" :key="index">{{item}}</li>
                                        </ul>
                                    </td>
                                </tr>
                            </tfoot>

                        </table>
                    </van-tab>
                    </template>
                </van-tabs>
            </section>

        </section>

        <section class="activity-rules">
            <ul>
                <li>活动规则：</li>
                <li v-for="(item,index) in activity_list.activityRules" :key="index">{{index+1}}.{{item}}</li>
            </ul>
        </section>

        <van-dialog v-model="dialog_value"  width="21.56rem" closeOnClickOverlay>
          <div slot="default" class="totems">
            <img :src="see_banner" alt="">
          </div>
        </van-dialog>

    </section>
</template>

<script>
import { activityData } from '@/api/home'
export default {
    name: 'formwork',
    data() {
        return {
            activity_list: {},
            van_active: 0,
            dialog_value: false,
            see_banner: ''
        }
    },
    created() {
        this.requireContext();
        this.getJson();
    },
    methods: {
        getJson() {
            let activity_list = {
                tabsTable: []
            }
            // let params = {
            //     pageCode: "TEST",
            //     relateType: 10,
            //     relateId: 1,
            //     communityId: this.$route.query.communityId,
            //     inviteCode: this.$route.query.inviteCode
            // }
            let params = {
                pageCode: this.$route.query.pageCode ? this.$route.query.pageCode: "1372816311683383296",// TEST
                inviteCode: this.$route.query.inviteCode ? this.$route.query.inviteCode : '',
                relateType: this.$route.query.relateType? this.$route.query.relateType: 10,
                relateId: this.$route.query.relateId ? this.$route.query.relateId : '1372816311683383296',
                isPc: 0,
                isH5: 1
            }
            activityData(params).then(res => {
                if (res.data.code != 200) {
                    return
                }
                let activityObj = res.data.data.activityObj || {};
                let commonObj = res.data.data.commonObj || {};
                let templateObj = res.data.data.templateObj || {};

                activity_list.tabsTable = []
                for (let i = 0; i < activityObj.activeList.length; i++) {
                    let tfoot = []
                    for (let k = 0; k < activityObj.activeList[i].rules.length; k++) {
                        tfoot.push(activityObj.activeList[i].rules[k].remark)
                    }
                    let thead = []
                    let tbody = []
                    if (activityObj.activeList[i].table && activityObj.activeList[i].table.length != 0) {
                        thead = activityObj.activeList[i].table[0]
                        tbody = activityObj.activeList[i].table.filter(function(item,index){
                            return index != 0;
                        })
                    }

                    activity_list.tabsTable.push({
                        label: activityObj.activeList[i].title,
                        thead: thead,
                        theadStyle: {
                            backgroung: activityObj.activeList[i].theadBg,
                            color: activityObj.activeList[i].theadColor
                        },
                        tbody: tbody,
                        tfoot: tfoot
                    })
                }
                
                let str0, str1, str2;
                let dataArr = activityObj.dataRange || []
                if (dataArr.length != 0) {
                    str0 = activityObj.dataRange[0].split("-");
                    str1 = activityObj.dataRange[1].split("-");
                    str2 = str0[0] + "年" + str0[1] + "月" + str0[2] + "日" + "-" + str1[0] + "年" + str1[1] + "月" + str1[2] + "日";
                }

                activity_list.title = activityObj.title;
                
                activity_list.activityDate = str2
                activity_list.recentPlayers = activityObj.recentPlayers
                activity_list.score = {
                    total: activityObj.score.total,
                    disbursementSpeed: activityObj.score.disbursementSpeed,
                    comprehensive: activityObj.score.comprehensive,
                    activityIndex: activityObj.score.activityIndex
                }
                let activityRules = [];
                let auRule = activityObj.activityRules || []
                for (let k = 0; k < auRule.length; k++) {
                    activityRules.push(activityObj.activityRules[k].remark);
                }
                activity_list.activityRules = activityRules

                let bannerArr = templateObj.banner || []
                for(let i =0; i < bannerArr.length;i++) {
                  templateObj.banner[i] = 'http://oss.bobovip8.com' + templateObj.banner[i]
                }
                activity_list.banner = templateObj.banner || [];
                activity_list.logo = 'http://oss.bobovip8.com' + templateObj.logo


                activity_list.sportsName = commonObj.communityName;
                activity_list.officialWebsite = commonObj.officialH5Website;// activityObj.officialWebsite
                activity_list.customerService = commonObj.customerService;

                this.activity_list = activity_list;
                console.log('-------', activity_list);
            })
        },
        requireContext() {
            let requireModule = require.context("@/assets/mock3", false, /\.json$/);
            requireModule = requireModule.keys();
            let fileNameArr = [];
            for (let i = 0; i < requireModule.length; i++) {
                fileNameArr.push(requireModule[i].substr(2, requireModule[i].length-7));
            }
            for (let i = 0; i < fileNameArr.length; i++) {
                if (this.$route.query.name == fileNameArr[i]) {
                    this.activity_list = require('@/assets/mock3/'+ fileNameArr[i] + '.json' );
                }
            }
        },
        appreciate(url) {
            this.dialog_value = true;
            this.see_banner = url;
        },
        cancelPrize() {
            this.dialog_value = false;
        }
    }
}
</script>

<style lang="scss" scoped>
#formwork {
    width: 100%;
    height: 100%;
    background: #F5F5F5;
    .banner {
        width: 100%;
        height: 11.87rem;
        img {
            width: 100%;
            height: 100%;
        }
    }
    .cooperation {
        width: 100%;
        padding: 0 0.4rem 0.62rem 0.4rem;
        box-sizing: border-box;
        position: relative;
        left: 0;
        top: -6.87rem;
        z-index: 10;
        .design-box {
            width: 100%;
            border-radius: 10px;
            background: white;
            padding: 0.5rem 0.5rem 1rem 0.5rem;
            box-sizing: border-box;
            p {
                margin: 0;
            }
            .title {
                width: 100%;
                height: 2rem;
                line-height: 2rem;
                color: #000000;
                font-size: 0.9rem;
                font-weight: 600;
                overflow: hidden;
            }
            .score {
                width: 100%;
                height: 2rem;
                line-height: 2rem;
                color: #FB5A02;
                span:nth-of-type(1) {
                    float: left;
                    font-size: 1rem;
                }
                span:nth-of-type(2) {
                    float: right;
                    font-size: 0.8rem;
                    margin-right: 0.5rem;
                }
            }
            .banner-list {
                width: 100%;
                height: 5.93rem;
                margin: 0.2rem 0 0.2rem 0;
                overflow-x: auto;
                li {
                    width: 7.81rem;
                    height: 100%;
                    float: left;
                    margin-right: 0.5rem;
                    img {
                        width: 100%;
                        height: 100%;
                    }
                }
            }
            .activity_date {
                width: 100%;
                height: 2rem;
                line-height: 2rem;
                color: #191919;
                font-size: 0.9rem;
                span:nth-of-type(1) {
                    font-size: 1rem;
                    float: left;
                    margin-right: 1.2rem;
                }
                span:nth-of-type(2) {
                    float: left;
                }
            }
            .logo-box {
                width: 100%;
                height: 4rem;
                text-align: left;
                padding: 0.5rem 0 0rem 0;
                box-sizing: border-box;
                dl {
                    width: 9rem;
                    height: 3rem;
                    margin: 0;
                    float: left;
                    overflow: hidden;
                    dt {
                        width: 3rem;
                        height: 100%;
                        float: left;
                        img {
                            width: 100%;
                            height: 100%;
                        }
                    }
                    dd {
                        width: 6rem;
                        height: 1.5rem;
                        line-height: 1.5rem;
                        float: left;
                        font-size: 0.7rem;
                        text-indent: 8px;
                        margin: 0;
                    }
                    dd:nth-of-type(1){
                        color: #191919;
                        font-size: 0.8rem;
                        font-weight: 600;
                    }
                }
                ul {
                    height: 3rem;
                    margin: 0;
                    float: right;
                    overflow: hidden;
                    li {
                        width: 2.5rem;
                        height: 100%;
                        float: left;
                        margin-right: 0.5rem;
                        img {
                            width: 1.5rem;
                            height: 1.5rem;
                            margin: 0 0.5rem 0 0.5rem;
                        }
                        span {
                            width: 100%;
                            display: inline-block;
                            font-size: 0.8rem;
                            text-align: center;
                        }
                    }
                }
            }
            .official {
                width: 100%;
                height: 3rem;
                font-size: 0.9rem;
                padding: 0.5rem 0 0.5rem 0;
                box-sizing: border-box;
                a {
                    color: #1D1D1D;
                    height: 2rem;
                    line-height: 2rem;
                    text-decoration: none;
                    img {
                        width: 1rem;
                        height: 1rem;
                    }
                    span {
                        vertical-align: middle;
                        margin-left: 0.3rem;
                    }
                }
                a:nth-of-type(1) {
                    float: left;
                    margin-left: 2rem;
                }
                a:nth-of-type(2) {
                    float: right;
                    margin-right: 2rem;
                }
            }
        }
        .tab-box {
            width: 100%;
            border-radius: 0.62rem;
            background: white;
            padding: 0.5rem 0.5rem 1rem 0.5rem;
            box-sizing: border-box;
            margin-top: 0.9rem;
            /deep/.van-tabs__content {
                padding: 0.8rem 0 0rem 0;
                box-sizing: border-box;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                border-radius: 0.62rem;
                border: 1px solid #ECECEC;
                border-style: hidden;// 消除掉外边框
                box-shadow: 0 0 0 1px #ECECEC;
                overflow: hidden;
            }
            th, td {
                border: 1px solid #ECECEC;
                padding: 5px;
                box-sizing: border-box;
            }
            thead th {
                height: 3rem;
                font-weight: 400;
                font-size: 0.8rem;
            }
            tbody td {
                height: 2.5rem;
                font-size: 0.8rem;
            }
            tfoot td {
                ul {
                    width: 100%;
                    margin: 0;
                    padding: 0 0 0.4rem 0;
                    box-sizing: border-box;
                    li {
                        width: 100%;
                        padding: 0.4rem 0 0 0;
                        box-sizing: border-box;
                        text-align: left;
                        font-size: 0.8rem;
                    }
                    li:nth-of-type(1) {
                        font-weight: 600;
                    }
                }
            }
        }

    }
    .activity-rules {
        width: 100%;
        background: white;
        padding: 0.5rem 0.5rem 0.8rem 0.5rem;
        box-sizing: border-box;
        margin-top: -6.5rem;
        ul {
            width: 100%;
            margin: 0;
            li {
                width: 100%;
                padding: 0.4rem 0 0 0;
                box-sizing: border-box;
                text-align: left;
                font-size: 0.8rem;
            }
            li:nth-of-type(1) {
                font-weight: 600;
            }
        }
    }
    /deep/ .van-overlay {
        -background-color: rgba(0,0,0,1);
    }
    /deep/ .van-dialog {
      background: none;
      .van-dialog__header {
        display: none;
      }
      .van-dialog__content {
        height: 12.06rem;
        .totems {
            width: 100%;
            height: 100%;
            img:nth-of-type(1) {
                width: 100%;
                height: 100%;
            }
        }
      }
      .van-dialog__footer {
        display: none;
      }
    }
}
</style>


