<template>
    <section class="moban">
        <img :src="activity_list.homeImg" alt="">
        <div class="official">
            <a :href="activity_list.homeLink">
                <img src="../../../public/formwork/yabo/icon_web.png" srcset="../../../public/formwork/yabo/icon_web@2x.png 2x" alt="">
                <span>进入官网</span>
            </a>
            <a :href="activity_list.serviceLink">
                <img src="../../../public/formwork/yabo/icon_lianxikefu.png" srcset="../../../public/formwork/yabo/icon_lianxikefu@2x.png 2x" alt="">
                <span>联系客服</span>
            </a>
        </div>
    </section>
</template>

<script>
import { templateList, gitConfig } from '@/api/home'
export default {
    name: 'moban',
    data() {
        return {
            activity_list: {}
        }
    },
    created() {
        console.log('---yd09----');
        this.requireContext();

        
        let search = this.$route.query
        let id = search.id
        let userId = search.userId
        let  data = { id: id, userId: userId }

        if(id) {
            templateList(data).then(res => {
                let headerList = res.data.data.template
                this.$set(this.activity_list, 'homeLink', headerList.gwJumpForH5)
                // this.$set(this.activity_list, 'homeLink', headerList.gwJump)
                this.$set(this.activity_list, 'homeImg', headerList.tpZp)
                this.$set(this.activity_list, 'serviceLink', headerList.kefuJump)
                this.gitConfigList()
            })
            return
        }

        
        this.gitConfigList()
    },
    methods: {
        gitConfigList() {
            let search = this.$route.query
            let params = {
                "communityId": search.communityId,
                "inviteCode": search.inviteCode
            }
            // console.log(search, search.communityId, search.communityId!=='null')
            if (!!search.communityId&&(search.communityId!=='null')) {
                gitConfig(params).then(res => {
                let headerList = res.data.data
                headerList.h5_url&&this.$set(this.activity_list, 'homeLink', headerList.h5_url)
                // headerList.qq&&this.$set(this.activity_list, 'serviceLink', "tencent://message/?uin=" + headerList.qq + "&Site=&Menu-=yes")
                var kefu101 = "tencent://message/?uin=" + headerList.qq + "&Site=&Menu-=yes";
                var kefu102 = "mqqwpa://im/chat?chat_type=wpa&uin=" + headerList.qq + "&version=1&src_type=web&web_src=oicqzone.com";
                if (headerList.qq) {
                    let regqq = this.checkInstalled('qq')
                    if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent) || /(Android)/i.test(navigator.userAgent)) {
                    this.$set(this.activity_list, 'serviceLink', regqq?kefu102:'https://im.qq.com/immobile/index.html')
                    } else {
                    this.$set(this.activity_list, 'serviceLink', regqq?kefu101:'https://im.qq.com/immobile/index.html')
                    }
                }
                })
            }
        },
        requireContext() {
            let requireModule = require.context("@/assets/mock4", false, /\.json$/);
            requireModule = requireModule.keys();
            let fileNameArr = [];
            for (let i = 0; i < requireModule.length; i++) {
                fileNameArr.push(requireModule[i].substr(2, requireModule[i].length-7));
            }
            for (let i = 0; i < fileNameArr.length; i++) {
                if (this.$route.query.name == fileNameArr[i]) {
                    this.activity_list = require('@/assets/mock4/'+ fileNameArr[i] + '.json' );
                }
            }
        },
    }
}
</script>

<style lang="scss" scoped>
.moban {
    width: 100%;
    img {
        width: 100%;
    }
    .official {
        width: 100%;
        height: 3rem;
        font-size: 0.9rem;
        padding: 0.5rem 1.5rem 0.5rem 1.5rem;
        box-sizing: border-box;
        position: absolute;
        top: 23.3rem;
        left: 0;
        a {
            color: #1D1D1D;
            height: 2rem;
            line-height: 1.7rem;
            border-radius: 4px;
            text-decoration: none;
            width: 49%;
            background: #fff;
            border: 1px solid #EBEEF5;
            img {
                width: 1rem;
                height: 1rem;
            }
            span {
                vertical-align: middle;
                margin-left: 0.3rem;
            }
        }
        a:nth-of-type(1) {
            float: left;
        }
        a:nth-of-type(2) {
            float: right;
        }
    }
}
</style>


