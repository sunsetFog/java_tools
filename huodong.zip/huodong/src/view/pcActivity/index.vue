<template>
    <section id="pcActivity">
        <!-- <div class="nav-table">
            <ul>
                <a :href="'#card'+firstIndex" v-for="(firstItem,firstIndex) in activity_list.tabsTable" :key="'tf' + firstIndex">
                    <li>
                        
                        <img :src="'/formwork/pc/card' + (firstIndex + 1) + '.png'" alt="">
                        <label>{{firstItem.label}}</label>
                        
                    </li>
                </a>
            </ul>
        </div> -->
        <section class="box-center">
            <div class="banner" v-if="relate_type == 10">
                <el-carousel height="330px" arrow="always">
                    <el-carousel-item v-for="(item,index) in activity_list.tabsTable" :key="index">
                        <viewer :images="[item.banner]">
                        <img :src="item.banner" alt="">
                        </viewer>
                    </el-carousel-item>
                </el-carousel>
            </div>
            <div class="banner" v-else>
                <viewer :images="[activity_list.bannerType]">
                <img :src="activity_list.bannerType" alt="">
                </viewer>
            </div>
            <div class="theme">
                <img class="logo" :src="activity_list.logo" alt="">
                <span class="sports-name">{{activity_list.sportsName}}</span>
                <span class="sports-title">{{activity_list.title}}</span>
                <a href="javascript:;" @click="toHome">
                    <span>进入官网</span>
                </a>
                <a href="javascript:;" @click="toKefu">
                    <img src="../../../public/formwork/pc/kefu.png" srcset="../../../public/formwork/pc/kefu@2x.png 2x" alt="">
                    <span>联系客服</span>
                </a>
            </div>

            <section class="show-table" v-for="(firstItem,firstIndex) in activity_list.tabsTable" :key="'ta' + firstIndex">
               <div class="title-img" :id="'card'+firstIndex">
                    <img :src="'/formwork/pc/card' + (firstIndex + 1) + '.png'" alt="">
                    <label>{{firstItem.label}}</label>
               </div>
                <table>
                    <thead :style="{ background: firstItem.theadStyle.backgroung, color: firstItem.theadStyle.color }">
                        <tr>
                            <th v-for="(item,index) in firstItem.thead" :key="'tr' + index">{{item}}</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item,oneIndex) in firstItem.tbody" :key="'te' + oneIndex">
                            <td  v-for="(val,twoIndex) in item" :key="'ti' + twoIndex">{{val}}</td>
                        </tr>
                    </tbody>
                    <!-- <tfoot v-if="firstItem.tfoot.length != 0">
                        <tr>
                            <td :colspan="firstItem.thead.length">
                                <ul>
                                    <li v-for="(item,index) in firstItem.tfoot" :key="'tl' + index">{{item}}</li>
                                </ul>
                            </td>
                        </tr>
                    </tfoot> -->
                </table>
                <section class="activity-rules">
                    <ul>
                        <p>
                            <img src="../../../public/formwork/pc/jiantou.png" alt="">
                            <span>活动说明</span>
                            <img src="../../../public/formwork/pc/jiantou.png" alt="">
                        </p>
                        <li v-for="(item,index) in firstItem.tfoot" :key="'tp' + index">{{index+1}}. {{item}}</li>
                    </ul>
                </section>
            </section>
        </section>
    </section>
</template>

<script>
import { activityData } from '@/api/home'
export default {
    name: "pcActivity",
    data() {
        return {
            activity_list: {},
            relate_type: 10
        }
    },
    created() {
        this.relate_type = this.$route.query.relateType ? Number(this.$route.query.relateType) : 10;
        this.requireContext();
        this.getJson();
    },
    methods: {
        toHome() {
          top.location.href=this.activity_list.officialWebsite
        },
        toKefu() {
          top.location.href=this.activity_list.customerService
        },
        getJson() {
            let activity_list = {
                tabsTable: []
            }
            /*
                火狐 1372822300834922496
                华体会 1372819702329376768
            */
            let params = {
                pageCode: this.$route.query.pageCode ? this.$route.query.pageCode: "1372819702329376768",// TEST
                inviteCode: this.$route.query.inviteCode ? this.$route.query.inviteCode : '',
                relateType: 10,
                relateId: this.$route.query.relateId ? this.$route.query.relateId : '1372819702329376768',
                isPc: 1,
                isH5: 0
            }
            activityData(params).then(res => {
                if (res.data.code != 200) {
                    return
                }
                let activityObj = res.data.data.activityObj || {};
                let commonObj = res.data.data.commonObj || {};
                let templateObj = res.data.data.templateObj || {};
                let nameType = '';
                if (this.relate_type == 1) {
                    nameType = '首存';
                } else if (this.relate_type == 2) {
                    nameType = '复存';
                } else if (this.relate_type == 3) {
                    nameType = '流水';
                } else if (this.relate_type == 4) {
                    nameType = '实物';
                } else if (this.relate_type == 5) {
                    nameType = 'vip';
                }

                activity_list.tabsTable = []
                for (let i = 0; i < activityObj.activeList.length; i++) {
                    let tfoot = []
                    for (let k = 0; k < activityObj.activeList[i].rules.length; k++) {
                        tfoot.push(activityObj.activeList[i].rules[k].remark)
                    }
                    let thead = []
                    let tbody = []
                    if (activityObj.activeList[i].table && activityObj.activeList[i].table.length != 0) {
                        thead = activityObj.activeList[i].table[0]
                        tbody = activityObj.activeList[i].table.filter(function(item,index){
                            return index != 0;
                        })
                    }

                    if (nameType == activityObj.activeList[i].typeName) {
                        activity_list.bannerType = activityObj.activeList[i].banner ?'http://oss.bobovip8.com' + activityObj.activeList[i].banner : '';
                    }


                    activity_list.tabsTable.push({
                        typeName: activityObj.activeList[i].typeName,
                        label: activityObj.activeList[i].title,
                        banner: activityObj.activeList[i].banner ?'http://oss.bobovip8.com' + activityObj.activeList[i].banner : '',
                        thead: thead,
                        theadStyle: {
                            backgroung: activityObj.activeList[i].theadBg,
                            color: activityObj.activeList[i].theadColor
                        },
                        tbody: tbody,
                        tfoot: tfoot
                    })
                }

                if (this.relate_type != 10) {
                    activity_list.tabsTable = activity_list.tabsTable.filter(function(item){
                        return nameType == item.typeName
                    })
                }
                

                activity_list.title = activityObj.title;
                
                // let activityRules = [];
                // for (let k = 0; k < activityObj.activityRules.length; k++) {
                //     activityRules.push(activityObj.activityRules[k].remark);
                // }
                // activity_list.activityRules = activityRules

                activity_list.logo = templateObj.logo ?'http://oss.bobovip8.com' + templateObj.logo : '';
                


                activity_list.sportsName = commonObj.communityName;
                activity_list.officialWebsite = commonObj.officialPcWebsite;// activityObj.officialWebsite
                activity_list.customerService = commonObj.customerService;

                this.activity_list = activity_list;
                console.log('-------', activity_list);
            })
        },
        requireContext() {
            let requireModule = require.context("@/assets/mock3", false, /\.json$/);
            requireModule = requireModule.keys();
            let fileNameArr = [];
            for (let i = 0; i < requireModule.length; i++) {
                fileNameArr.push(requireModule[i].substr(2, requireModule[i].length-7));
            }
            let isName = this.$route.query.name ? this.$route.query.name : 'pcTest'
            for (let i = 0; i < fileNameArr.length; i++) {
                if (isName == fileNameArr[i]) {
                    this.activity_list = require('@/assets/mock3/'+ fileNameArr[i] + '.json' );
                }
            }
        },
    }
}
</script>


<style lang="scss" scoped>
#pcActivity {
    width: 100%;
    height: 100%;
    -background: #fff;
    .nav-table {
        width: 200px;
        position: fixed;
        right: 10px;
        top: 150px;
        z-index: 99;
        ul {
            li, a {
                width: 100%;
                height: 40px;
                margin: 2px 0;
                float: left;
                position: relative;
                img {
                    width: 100%;
                    height: 100%;
                    position: absolute;
                    left: 0px;
                    top: 0px;
                }
                label {
                    color: #fff;
                    font-size: 14px;
                    font-weight: 600;
                    position: absolute;
                    left: 60px;
                    top: 13px;
                }
            }
        }
    }
    .box-center {
        width: 950px;
        min-height: 1000px;
        background: #fff;
        margin: 0px auto;
        padding: 15px 45px 20px 45px;
        box-sizing: border-box;
        // border: 1px solid #999999;
        .banner {
            width: 100%;
            height: 330px;
            overflow: hidden;
            img {
                width: 100%;
                height: 100%;
            }
        }
        .theme {
            width: 100%;
            height: 60px;
            position: relative;
            margin-bottom: 60px;
            .logo {
                height: 110px;
                border-radius: 50%;
                position: absolute;
                right: 725px;
                top: -20px;
                z-index: 5;
            }
            .sports-name {
                font-size: 16px;
                font-weight: 600;
                position: absolute;
                left: 140px;
                top: 10px;
            }
            .sports-title {
                font-size: 14px;
                position: absolute;
                left: 140px;
                top: 40px;
            }
            a {
                width: 170px;
                color: #fff;
                line-height: 30px;
                text-decoration: none;
                position: absolute;
                img {
                    width: 16px;
                    height: 16px;
                }
                span {
                    vertical-align: middle;
                    margin-left: 5px;
                    font-size: 14px;
                }
            }
            a:nth-of-type(1) {
                right: 180px;
                top: 10px;
                background: #3485FB;
            }
            a:nth-of-type(2) {
                right: 0px;
                top: 10px;
                background: #FF6C21;
            }
        }
        .show-table {
            margin-top: 40px;
            padding: 0 0 40px 0;
            box-sizing: border-box;
            .title-img {
                width: 100%;
                height: 70px;
                margin: 10px 0;
                position: relative;
                img {
                    width: 410px;
                    height: 70px;
                    position: absolute;
                    left: 0px;
                    top: 0px;
                }
                label {
                    color: #fff;
                    font-size: 14px;
                    font-weight: 600;
                    position: absolute;
                    left: 100px;
                    top: 30px;
                }
            }
            table {
                width: 100%;
                border-collapse: collapse;
                border-radius: 10px;
                border-style: hidden;
                box-shadow: 0 0 0 1px #ECECEC;
                overflow: hidden;
                th, td {
                    border: 1px solid #ECECEC;
                    padding: 5px;
                }
                th {
                    font-size: 16px;
                }
                td {
                    font-size: 16px;
                }
                tfoot td {
                    ul {
                        width: 100%;
                        margin: 0;
                        padding: 0 0 6px 0;
                        box-sizing: border-box;
                        li {
                            width: 100%;
                            padding: 6px 0 0 0;
                            box-sizing: border-box;
                            text-align: left;
                            font-size: 13px;
                        }
                        li:nth-of-type(1) {
                            font-weight: 600;
                        }
                    }
                }
            }


            .activity-rules {
                width: 100%;
                background: white;
                padding: 10px 8px 20px 8px;
                box-sizing: border-box;
                margin-top: 20px;
                ul {
                    width: 100%;
                    margin: 0;
                    li, p {
                        width: 100%;
                        padding: 6px 0 0 0;
                        box-sizing: border-box;
                        text-align: left;
                        font-size: 15px;
                    }
                    p {
                        margin: 0 0 20px 0;
                        padding: 0;
                        text-align: center;
                        img {
                            width: 80px;
                            height: 20px;
                        }
                        img:nth-of-type(1) {
                            
                        }
                        span {
                            font-weight: 600;
                            margin: 0 20px;
                            color: #3F74F7;
                            font-size: 15px;
                        }
                        img:nth-of-type(2) {
                            transform: rotate(180deg);
                        }
                    }
                }
            }

            
        }
        
    }
}
</style>