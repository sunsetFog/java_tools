import Vue from "vue";
import VueRouter from "vue-router";
Vue.use(VueRouter);

// import goodList from "./components/good/goodList"

const routes = [
  {
        path: '/',
        name: 'one',
        component: resolve => require(['./one.vue'], resolve),
        children: []
},
  {
  path: "/one",
  component: resolve => require(['./one.vue'], resolve),
},
{
  path: "/two",
  component: resolve => require(['./two.vue'], resolve),
},
{
  path: "/test1",
  component: resolve => require(['./test1.vue'], resolve),
},
{
  path: "/test2",
  component: resolve => require(['./test2.vue'], resolve),
},
{
  path: "/luckDraw",
  component: resolve => require(['./view/luckDraw/luckDraw.vue'], resolve)
},
{
  path: "/gongGe",
  component: resolve => require(['./view/luckDraw/gongGe.vue'], resolve)
},
{
  path: "/turntable",
  component: resolve => require(['./view/luckDraw/turntable.vue'], resolve)
},
{
  path: "/pcTurntable",
  component: resolve => require(['./view/luckDraw/pcTurntable.vue'], resolve)
},
{
  path: "/formwork",
  component: resolve => require(['./view/formwork/formwork.vue'], resolve)
},
{
  path: "/pcActivity",
  component: resolve => require(['./view/pcActivity/index.vue'], resolve)
},
{
  path: "/special",
  component: resolve => require(['./view/formwork/index.vue'], resolve)
},
{
  path: "/appActivity",
  component: resolve => require(['./view/platformActivities/appActivity.vue'], resolve)
},
{
  path: "/appWelfare",
  component: resolve => require(['./view/platformActivities/appWelfare.vue'], resolve)
},
{
  path: "/pcActivityPage",
  component: resolve => require(['./view/platformActivities/pcActivityPage.vue'], resolve)
},
{
  path: "/communityWelfare",
  component: resolve => require(['./view/platformActivities/communityWelfare.vue'], resolve)
},
{
  path: "/pcWelfare",
  component: resolve => require(['./view/platformActivities/pcWelfare.vue'], resolve)
}
]

var router = new VueRouter({
  routes
})
export default router;