<template>
  <div id="app">
  <router-view/>
</div>
</template>

<script>
export default {
  name: 'App',
  components: {
  },
  data(){
    return {
      headerList: {}
    }
  },

  methods:{
  }
}
</script>

<style lang="scss">
#app {
  height: 100%;
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
.sure-dialog {
  width: 21.56rem;
  .van-dialog__content {
    height: 6.5rem;
    .van-dialog__message {
      font-size: 0.875rem;
    }
  }
  .van-button {
    height: 3rem;
    line-height: 3rem;
    font-size: 1rem;
  }
}
</style>
