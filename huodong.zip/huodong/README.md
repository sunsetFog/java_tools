# 社区活动

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

http://miniactive.bobovip8.com/#/formwork?relateId=1438500174572814336&inviteCode=undefined&pageCode=1438500174572814336&relateType=10

http://miniactive.bobovip2.com/#/pcActivity?pageCode=1372816311683383296&inviteCode=null&relateType=10&relateId=1372816311683383296